<option value="" selected disabled>-- Select <?php echo e($cat); ?> -- </option>
<?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <option value="<?php echo e($item['label_id']); ?>" data-label-name="<?php echo e($item['label_name']); ?>" data-stock="<?php echo e($item['stock']); ?>"
        data-price="<?php echo e($item['price']); ?>">
        <?php echo e($item['label_name']); ?>

    </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/jobcard/component/labels.blade.php ENDPATH**/ ?>