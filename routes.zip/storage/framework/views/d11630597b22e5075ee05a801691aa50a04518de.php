<div class="dropdown_profile ulprofile">
    <?php $userid = Auth::User()->id; ?>
    <?php if(getAccessStatusUser('Settings', $userid) == 'yes'): ?>
    <?php if(getActiveAdmin($userid) == 'yes'): ?>
    <a href="<?php echo url('setting/general_setting/list'); ?>"><img src="<?php echo e(URL::asset('public/img/dashboard/Settings.png')); ?>" alt="admin" width="40px" height="40px" class="border-0 m-1  display-left"></a>
    <?php else: ?>
    <a href="<?php echo url('setting/timezone/list'); ?>"><img src="<?php echo e(URL::asset('public/img/dashboard/Settings.png')); ?>" alt="admin" width="40px" height="40px" class="border-0 m-1  display-left"></a>
    <?php endif; ?>
    <?php endif; ?>
    <div class="vr display-none"></div>
    <a href="javascript:;" class=" dropdown_profile pt-2 pb-2 authpic" data-bs-toggle="dropdown" aria-expanded="false">
      <?php if(!empty(Auth::user()->id)): ?>
      <?php if(Auth::user()->role == 'admin'): ?>
      <img src="<?php echo e(URL::asset('public/admin/' . Auth::user()->image)); ?>" alt="admin" width="40px" height="40px" class="rounded  display-right">
      <?php endif; ?>

      <?php if(Auth::user()->role == 'Customer'): ?>
      <img src="<?php echo e(URL::asset('public/customer/' . Auth::user()->image)); ?>" alt="customer" width="40px" height="40px" class="rounded  display-right">
      <?php endif; ?>

      <?php if(Auth::user()->role == 'Supplier'): ?>
      <img src="<?php echo e(URL::asset('public/supplier/' . Auth::user()->image)); ?>" alt="supplier" width="40px" height="40px" class="rounded  display-right">
      <?php endif; ?>

      <?php if(Auth::user()->role == 'employee'): ?>
      <img src="<?php echo e(URL::asset('public/employee/' . Auth::user()->image)); ?>" alt="employee" width="40px" height="40px" class="rounded  display-right">
      <?php endif; ?>

      <?php if(Auth::user()->role == 'supportstaff'): ?>
      <img src="<?php echo e(URL::asset('public/supportstaff/' . Auth::user()->image)); ?>" alt="supportstaff" width="40px" height="40px" class="rounded  display-right">
      <?php endif; ?>

      <?php if(Auth::user()->role == 'accountant'): ?>
      <img src="<?php echo e(URL::asset('public/accountant/' . Auth::user()->image)); ?>" alt="accountant" width="40px" height="40px" class="rounded  display-right">
      <?php endif; ?>

      <?php if(Auth::user()->role == 'branch_admin'): ?>
      <img src="<?php echo e(URL::asset('public/branch_admin/' . Auth::user()->image)); ?>" alt="branch_admin" width="40px" height="40px" class="rounded  display-right">
      <?php endif; ?>

      <?php if(Auth::user()->role == 'spare_part_vendor'): ?>
      <img src="<?php echo e(URL::asset('public/spare_part_vendor/' . Auth::user()->image)); ?>" alt="spare part vendor" width="40px" height="40px" class="rounded  display-right">
      <?php endif; ?>

      <?php if(Auth::user()->role == ''): ?>
      <img src="<?php echo e(URL::asset('public/customer/' . Auth::user()->image)); ?>" alt="customer" width="40px" height="40px" class="rounded  display-right">
      <?php endif; ?>
      <?php endif; ?>


      <!-- <?php if(!empty(Auth::user()->id)): ?>
        <?php echo e(Auth::user()->name); ?>

      <?php endif; ?> -->
      
    </a>
    <ul class="dropdown-menu dropdown-usermenu float-end" style="width: 1px;">
      <li><a class="dropdown-item profile" href="<?php echo url('setting/profile'); ?>"><i class="fa fa-user me-2" aria-hidden="true"></i><?php echo e(trans('message.Profile')); ?></a></li>
      <li>
        <a class="logoutConfirm dropdown-item"><i class="fa fa-power-off" aria-hidden="true"></i> <?php echo e(trans('message.Logout')); ?></a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
        </form>
        <!-- <a title="<?php echo e(trans('message.Logout')); ?>" href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
          <i class="fa fa-power-off" aria-hidden="true"></i> <?php echo e(trans('message.Logout')); ?>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
          </form>
        </a> -->
      </li>
    </ul>
  </div>
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['supplier_add', 'product_add', 'purchase_add', 'customer_add','employee_add','supportstaff_add','accountant_add','branchAdmin_add','vehicle_add','vehicletype_add','vehiclebrand_add','colors_add','service_add','quotation_add','invoice_add','jobcard_add','gatepass_add','taxrate_add','paymentmethod_add','income_add','expense_add','salespart_add','rto_add','customfield_add','observationlibrary_add','branch_add'])): ?>
  <div class="dropdown_toggle ulprofile global_plus">
    <img src="<?php echo e(URL::asset('public/img/icons/Add.png')); ?>" alt="Add" width="40px" height="40px" class="m-1 dropdown-toggle border-0" type="button" id="dropdownMenuButtonAction" data-bs-toggle="dropdown" aria-expanded="false">
    <ul class="dropdown-menu heder-dropdown-menu action_dropdown shadow py-2 overflow-auto max-height-245" aria-labelledby="dropdownMenuButtonAction">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/supplier/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Suppliers')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/product/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Product')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/purchase/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Purchase')); ?></a></li>
      <li><a class="dropdown-item" href="<?php echo url('/purchase/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Stock')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/customer/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Customers')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/employee/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Employees')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supportstaff_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/supportstaff/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Support Staff')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accountant_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/accountant/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Accountant')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branchAdmin_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/branchadmin/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Branch Admin')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/vehicle/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Vehicles')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicletype_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/vehicletype/vehicletypeadd'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Vehicle Type')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehiclebrand_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/vehiclebrand/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Vehicle Brand')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehiclemodel_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/vehicalmodel/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Vehicle Model')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('colors_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/color/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Colors')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/service/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Services')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotation_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/quotation/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Quotation')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/invoice/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Invoices')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jobcard_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/service/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.JobCard')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gatepass_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/gatepass/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Gate Pass')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('taxrate_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/taxrates/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Tax Rates')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('paymentmethod_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/payment/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Payment Method')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('income_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/income/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Income')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/expense/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Expenses')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('salespart_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/sales_part/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Part Sells')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rto_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/rto/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Compliances')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customfield_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('setting/custom/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Custom Fields')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('observationlibrary_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/observation/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Observation Library')); ?></a></li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branch_add')): ?>
      <li><a class="dropdown-item" href="<?php echo url('/branch/add'); ?>"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e(trans('message.Branch')); ?></a></li>
      <?php endif; ?>
    </ul>
  </div>
  <?php endif; ?><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/dashboard/profile.blade.php ENDPATH**/ ?>