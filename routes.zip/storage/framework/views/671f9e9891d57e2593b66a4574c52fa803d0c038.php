
<?php $__env->startSection('content'); ?>
<style>
  @media screen and (max-width:540px) {
    div#vehicle_info {
      margin-top: -169px;
    }

    span.titleup {
      /* margin-left: -10px; */
    }
  }
</style>
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle">
            <a id="menu_toggle"><i class="fa fa-bars sidemenu_toggle"></i></a><span class="titleup"><?php echo e(trans('message.Vehicles')); ?></a>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle_add')): ?>
              <a href="<?php echo url('/vehicle/add'); ?>" id="" class="addbotton">
                <img src="<?php echo e(URL::asset('public/img/icons/plus Button.png')); ?>">
              </a>
            </span>
            <?php endif; ?>
          </div>

          <?php echo $__env->make('dashboard.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
      </div>
    </div>
    <?php echo $__env->make('success_message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
    <?php if(!empty($vehicals) && count($vehicals) > 0): ?>
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel mb-0">
          <table id="supplier" class="table jambo_table" style="width:100%">
            <thead>
              <tr>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle_delete')): ?>
                <th> </th>
                <?php endif; ?>
                <th><?php echo e(trans('message.Image')); ?></th>
                <th><?php echo e(trans('message.Type')); ?></th>
                <th><?php echo e(trans('message.Model Name')); ?></th>
                <th><?php echo e(trans('message.Number Plate')); ?></th>
                <th><?php echo e(trans('message.Customer Name')); ?></th>
                <!-- <th><?php echo e(trans('message.Price')); ?> (<?php echo getCurrencySymbols(); ?>)</th> -->
                <th><?php echo e(trans('message.Date Of Manufacturing')); ?></th>
                <th><?php echo e(trans('message.Last Service Date')); ?></th>
                <th><?php echo e(trans('message.Upcoming Service Date')); ?></th>
                <th><?php echo e(trans('message.Engine No')); ?></th>
                <th><?php echo e(trans('message.Action')); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php $i = 1; ?>
              <?php if(!empty($vehicals)): ?>
              <?php $__currentLoopData = $vehicals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr data-user-id="<?php echo e($vehicals->id); ?>">
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle_delete')): ?>
                <td>
                  <label class="container checkbox">
                    <input type="checkbox" name="chk">
                    <span class="checkmark"></span>
                  </label>
                </td>
              <?php endif; ?>
                <?php $vehicleimage = getVehicleImage($vehicals->id); ?>
                <td><a href="<?php echo url('/vehicle/list/view/' . $vehicals->id); ?>"><img src="<?php echo e(URL::asset('public/vehicle/' . $vehicleimage)); ?>" width="52px" height="52px" class="datatable_img"></a></td>
                <td><a href="<?php echo url('/vehicle/list/view/' . $vehicals->id); ?>"><?php echo e(getVehicleType($vehicals->vehicletype_id)); ?></a></td>
                <td><?php echo e($vehicals->modelname); ?></td>
                <td><?php echo e($vehicals->number_plate ?? trans('message.Not Added')); ?> 
                </td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_view')): ?>
                <td>
                  <a href="<?php echo url('/customer/list/' . $vehicals->customer_id); ?>"> <?php echo e(getCustomerName($vehicals->customer_id) ?? trans('message.Not Added')); ?> 
                  </a>
                </td>
                <?php else: ?>
                <td>
                  <?php echo e(getCustomerName($vehicals->customer_id) ?? trans('message.Not Added')); ?> 
                </td>
                <?php endif; ?> 
                <td>
                  <?php if(!empty($vehicals->dom)): ?>
                  <?php echo e(date(getDateFormat(), strtotime($vehicals->dom))); ?>

                  <?php else: ?>
                  <?php echo e(trans('message.Not Added')); ?>

                  <?php endif; ?>
                </td>
                <td><?php echo e($vehicals->lastServiceDate ? $vehicals->lastServiceDate->format('Y-m-d') : 'No service records'); ?> </td>
                <td><?php echo e($vehicals->upcomingServiceDate ? $vehicals->upcomingServiceDate->format('Y-m-d') : 'No service records'); ?> </td>
                <td><?php echo e($vehicals->engineno ?? trans('message.Not Added')); ?> </td>
                
                
                <td>
                  <div class="dropdown_toggle">
                    <img src="<?php echo e(URL::asset('public/img/list/dots.png')); ?>" class="btn dropdown-toggle border-0" type="button" id="dropdownMenuButtonaction" data-bs-toggle="dropdown" aria-expanded="false">

                    <ul class="dropdown-menu heder-dropdown-menu action_dropdown shadow py-2" aria-labelledby="dropdownMenuButtonaction">
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle_view')): ?>
                      <li><a class="dropdown-item" href="<?php echo url('/vehicle/list/view/' . $vehicals->id); ?>"><img src="<?php echo e(URL::asset('public/img/list/Vector.png')); ?>" class="me-3"><?php echo e(trans('message.View')); ?></a></li>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle_edit')): ?>
                      <li><a class="dropdown-item" href="<?php echo url('/vehicle/list/edit/' . $vehicals->id); ?>"><img src="<?php echo e(URL::asset('public/img/list/Edit.png')); ?>" class="me-3"> <?php echo e(trans('message.Edit')); ?></a></li>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle_delete')): ?>
                      <div class="dropdown-divider m-0"></div>
                      <li><a class="dropdown-item sa-warning" url="<?php echo url('/vehicle/list/delete/' . $vehicals->id); ?>" style="color:#FD726A"><img src="<?php echo e(URL::asset('public/img/list/Delete.png')); ?>" class="me-3"><?php echo e(trans('message.Delete')); ?></a></li>
                      <?php endif; ?>
                    </ul>
                  </div>
                </td>
              </tr>
              <?php $i++; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            <tbody>
            </tbody>
          </table>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle_delete')): ?>
          <button id="select-all-btn" class="btn select_all"><input type="checkbox" name="selectAll"> <?php echo e(trans('message.Select All')); ?></button>
          <button id="delete-selected-btn" class="btn btn-danger text-white border-0" data-url="<?php echo url('/vehicle/list/delete/'); ?>"><i class="fa fa-trash" aria-hidden="true"></i></button>
          <?php endif; ?>
        </div>
      </div>
    <?php else: ?>
      <p class="d-flex justify-content-center mt-5 pt-5"><img src="<?php echo e(URL::asset('public/img/dashboard/No-Data.png')); ?>" width="300px"></p>
    <?php endif; ?>
    </div>
  </div>
</div>
<!-- /page content -->


<!-- Scripts starting -->
<script src="<?php echo e(URL::asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>
<!-- language change in user selected -->
<script>
  $(document).ready(function() {

    var search = "<?php echo e(trans('message.Search...')); ?>";
    var info = "<?php echo e(trans('message.Showing page _PAGE_ - _PAGES_')); ?>";
    var zeroRecords = "<?php echo e(trans('message.No Data Found')); ?>";
    var infoEmpty = "<?php echo e(trans('message.No records available')); ?>";

    $('#supplier').DataTable({

      columnDefs: [{
        width: 2,
        targets: 0
      }],
      fixedColumns: true,
      paging: true,
      scrollCollapse: true,
      scrollX: true,
      // scrollY: 300,

      responsive: true,
      "language": {
        lengthMenu: "_MENU_ ",
        info: info,
        zeroRecords: zeroRecords,
        infoEmpty: infoEmpty,
        infoFiltered: '(filtered from _MAX_ total records)',
        searchPlaceholder: search,
        search: '',
        paginate: {
          previous: "<",
          next: ">",
        }
      },
      aoColumnDefs: [{
        bSortable: false,
        aTargets: [-1]
      }],
    });


    /*delete vehical*/
    $('body').on('click', '.sa-warning', function() {

      var url = $(this).attr('url');

      var msg1 = "<?php echo e(trans('message.Are You Sure?')); ?>";
      var msg2 = "<?php echo e(trans('message.You will not be able to recover this data afterwards!')); ?>";
      var msg3 = "<?php echo e(trans('message.Cancel')); ?>";
      var msg4 = "<?php echo e(trans('message.Yes, delete!')); ?>";

      swal({
        title: msg1,
        text: msg2,
        icon: 'warning',
        cancelButtonColor: '#C1C1C1',
        buttons: [msg3, msg4],
        dangerMode: true,
      }).then((willDelete) => {
        if (willDelete) {
          window.location.href = url;
        }
      });
    });
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/vehicle/list.blade.php ENDPATH**/ ?>