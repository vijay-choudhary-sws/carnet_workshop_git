
<?php $__env->startSection('content'); ?>

<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="nav_menu">
                <nav>
                    <div class="nav toggle">
                        <a id="menu_toggle"><i class="fa fa-bars sidemenu_toggle"></i></a><span class="titleup"> <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?></span>
                    </div>

                    <?php echo $__env->make('dashboard.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </nav>
            </div>
        </div>
    </div>
    <?php if(session('message')): ?>
    <div class="row massage">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="checkbox checkbox-success checkbox-circle mb-2 alert alert-success alert-dismissible fade show">
                <input id="checkbox-10" type="checkbox" checked="">
                <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(session('message')); ?> </label>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" style="padding: 1rem 0.75rem;"></button>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="d-flex justify-content-center align-items-center" style="height: 80vh;">
        <section id="" class="">
            <h4><?php echo e(trans("Oops! You don't have the access for this page contact to administrator.")); ?></h4>
            <center><a class="btn btn-success" href="<?php echo e(URL::previous()); ?>"><?php echo e(trans('GO Back')); ?></a></center>
        </section>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/errors/403.blade.php ENDPATH**/ ?>