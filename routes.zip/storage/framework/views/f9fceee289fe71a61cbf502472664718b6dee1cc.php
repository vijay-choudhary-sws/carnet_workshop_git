<?php if(session('message')): ?>
<div class="row massage">
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="checkbox checkbox-success checkbox-circle mb-2 alert alert-success alert-dismissible fade show">

      <?php if(session('message') == 'Successfully Submitted'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Successfully Submitted')); ?> </label>
      <?php elseif(session('message') == 'Successfully Updated'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Successfully Updated')); ?> </label>
      <?php elseif(session('message') == 'Successfully Deleted'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Successfully Deleted')); ?> </label>
      <?php elseif(session('message') == 'Data not available'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Data not available')); ?></label>
      <?php elseif(session('message') == 'Date is already inserted'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Date is already inserted')); ?></label>
      <?php elseif(session('message') == 'Please select time which is greater than start time'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Please select time which is greater than start time')); ?></label>
      <?php elseif(session('message') == 'This color is used with a vehicle record. So you can not delete it.'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.This color is used with a vehicle record. So you can not delete it.')); ?></label>
      <?php elseif(session('message') == 'Successfully Sent'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Successfully Sent')); ?></label>
      <?php elseif(session('message') == 'Error! Something went wrong.'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Error! Something went wrong.')); ?></label>
      <?php elseif(session('message') == 'Duplicate Data'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Duplicate Data')); ?></label>
      <?php elseif(session('message') == 'Supplier Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Supplier Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Supplier Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Supplier Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Supplier Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Supplier Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Product Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Product Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Product Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Product Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Product Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Product Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Purchase Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Purchase Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Purchase Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Purchase Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Purchase Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Purchase Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Customer Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Customer Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Customer Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Customer Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Customer Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Customer Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Employee Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Employee Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Employee Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Employee Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Employee Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Employee Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Supportstaff Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Supportstaff Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Supportstaff Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Supportstaff Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Supportstaff Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Supportstaff Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Accountant Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Accountant Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Accountant Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Accountant Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Accountant Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Accountant Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Branch Admin Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Branch Admin Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Branch Admin Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Branch Admin Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Branch Admin Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Branch Admin Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Vehicle Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Vehicle Type Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Type Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Type Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Type Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Type Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Type Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Vehicle Brand Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Brand Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Brand Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Brand Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Brand Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Brand Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Color Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Color Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Color Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Color Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Color Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Color Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Service Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Service Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Service Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Service Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Service Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Service Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Quotation Created Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Quotation Created Successfully')); ?></label>
      <?php elseif(session('message') == 'Quotation Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Quotation Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Quotation Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Quotation Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Invoice Created Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Invoice Created Successfully')); ?></label>
      <?php elseif(session('message') == 'Invoice Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Invoice Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Invoice Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Invoice Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Gatepass Created Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Gatepass Created Successfully')); ?></label>
      <?php elseif(session('message') == 'Gatepass Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Gatepass Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Gatepass Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Gatepass Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Tax Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Tax Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Tax Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Tax Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Tax Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Tax Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Payment Method Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Payment Method Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Payment Method Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Payment Method Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Payment Method Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Payment Method Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Income Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Income Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Income Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Income Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Income Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Income Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Expense Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Expense Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Expense Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Expense Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Expense Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Expense Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Vehicle Sell Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Sell Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Sell Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Sell Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Sell Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Sell Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Part Sell Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Part Sell Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Part Sell Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Part Sell Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Part Sell Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Part Sell Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Compliance Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Compliance Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Compliance Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Compliance Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Compliance Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Compliance Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Email Template Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Email Template Updated Successfully')); ?></label>

      <?php elseif(session('message') == 'Customfield Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Customfield Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Customfield Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Customfield Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Customfield Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Customfield Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Branch Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Branch Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Branch Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Branch Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Branch Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Branch Deleted Successfully')); ?></label>

      <?php elseif(session('message') == 'Jobcard Process Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Jobcard Process Successfully')); ?></label>
      <?php elseif(session('message') == 'General Settings Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.General Settings Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Other Settings Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Other Settings Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Access Rights Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Access Rights Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Business Hours Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Business Hours Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Stripe Settings Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Stripe Settings Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Business Holiday Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Business Holiday Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Business Holiday Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Business Holiday Deleted Successfully')); ?></label>
      <?php elseif(session('message') == 'Payment Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Payment Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Email Settings Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Email Settings Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Stock Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Stock Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Observation Library Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Observation Library Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Quotation Status Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Quotation Status Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'This Record is Duplicate'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.This Record is Duplicate')); ?></label>
      <?php elseif(session('message') == 'Vehicle Model Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Model Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Model Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Model Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Vehicle Model Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Vehicle Model Deleted Successfully')); ?></label>
       <?php elseif(session('message') == 'Spare Part Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Spare Part Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Spare Part Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Spare Part Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Spare Part Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Spare Part Deleted Successfully')); ?></label>
      <?php elseif(session('message') == 'Tool Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Tool Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Tool Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Tool Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Tool Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Tool Deleted Successfully')); ?></label>
      <?php elseif(session('message') == 'Lubricant Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Lubricant Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Lubricant Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Lubricant Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Lubricant Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Lubricant Deleted Successfully')); ?></label>
      <?php elseif(session('message') == 'Accessory Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Accessory Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Accessory Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Accessory Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Accessory Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Accessory Deleted Successfully')); ?></label>
      <?php elseif(session('message') == 'Unit Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Unit Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Unit Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Unit Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Unit Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Unit Deleted Successfully')); ?></label>
      <?php elseif(session('message') == 'Category Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Category Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Category Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Category Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Category Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Category Deleted Successfully')); ?></label>
      <?php elseif(session('message') == 'Spare Part Vendor Added Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Spare Part Vendor Added Successfully')); ?></label>
      <?php elseif(session('message') == 'Spare Part Vendor Updated Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Spare Part Vendor Updated Successfully')); ?></label>
      <?php elseif(session('message') == 'Spare Part Vendor Deleted Successfully'): ?>
      <label for="checkbox-10 colo_success" style="margin-left: 20px;font-weight: 600;"> <?php echo e(trans('message.Spare Part Vendor Deleted Successfully')); ?></label>
      <?php endif; ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" style="padding: 1rem 0.75rem;"></button>
    </div>
  </div>
</div>
<?php endif; ?><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/success_message/message.blade.php ENDPATH**/ ?>