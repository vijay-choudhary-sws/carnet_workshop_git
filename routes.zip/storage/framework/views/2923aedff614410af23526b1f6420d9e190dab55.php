<option value="" selected disabled>-- Select Item --</option>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($value->id); ?>"><?php echo e($value->name.', '.'Stock='.$value->stock.', Price='.$value->price); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/purchase_spare_part/component/item.blade.php ENDPATH**/ ?>