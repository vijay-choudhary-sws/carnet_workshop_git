<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fils): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $destroy_url = route('newjobcard.multiimagedelete');
    ?>
    <div class="col-md-2 mt-2">
        <a href="#!" onclick="delete_multiple_image('<?php echo e($destroy_url); ?>', this)" class="position-relative d-block" data-id="<?php echo e($fils->id); ?>">
            <span class="position-absolute bg-danger text-white p-1">
                <i class="fa fa-trash" aria-hidden="true"></i>
            </span>
        </a>
        <img src="<?php echo e(asset('public/uploads/gumasta/')); ?>/<?php echo e($fils->path); ?>" id="outlet_images_prev1" class="img-thumbnail" alt="" width="100" height="100">
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/new_jobcard/outlet_imagesmultiple.blade.php ENDPATH**/ ?>