<!DOCTYPE html>
<?php
use Illuminate\Support\Str;
?>
<html dir="" lang="en">
<style>
  /* CSS */
  .select2-container--invalid .select2-selection {
    border-color: red;
  }

  /* active dropdown */

  .dropdown {
    position: relative;
    display: inline-block;
    color: white;
    /* padding: 15px; */
    font-size: 14px;
    border: none;
    padding-top: 12px;
    padding-bottom: 12px;
    padding-left: 14px;
    /* padding-right: 16px; */

  }

  .li {
    background-color: #EA6B00;
    color: white;
    /* padding: 15px; */
    font-size: 14px;
    border: none;
    padding-top: 12px;
    padding-bottom: 12px;
    padding-left: 14px;
    padding-right: 16px;
    cursor: pointer;
  }

  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #FFEFE6;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    z-index: 1;
    inset: 0px 240px auto;
    height: auto;
    width: 222px;
    padding-left: 8px;

  }

  .dropdown-content a {
    color: #5B5D6E;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    margin-top: 3px;
  }

  .dropdown-content a:hover {
    background-color: #FFEFE6;
    color: #EA6B00;
  }

  .dropdown:hover .dropdown-content {
    display: block;
  }

  .nav.side-menu>li.active,
  .nav.side-menu>li.current-page {
    /* border-right: 5px solid #1abb9c; */
    background-color: #FFFFFF;
  }

  .dropdown a {
    color: #454545;
  }

  .dropdown>a:hover {
    color: #454545;
  }

  .dropdown {
    color: #454545;
  }

  .nav.side-menu>li.active>.dropdown>a {
    -webkit-text-fill-color: #454545;
  }

  li.active:hover {
    color: #454545;
  }

  .nav.side-menu>li.active,
  .nav.side-menu>li.current-page>a {
    color: #454545;
    --bs-nav-link-hover-color: #454545;
  }

  span.titleup:hover {
    color: #333333;
  }

  .nav.toggle:hover {
    color: #595F69;
  }

  li>.dropdown>a {
    color: #FFFFFF;
  }

  li>.dropdown {
    color: #595F69;
  }

  .dropdown:hover {
    background-color: #FFFFFF;
    color: #454545;
    width: 240px;
  }

  .dropdown:hover>a {
    color: #454545;
  }

  /* --------- side dropdown menu in mobile screen ------------ */
  /* i.fa-solid.fa-sliders {
    margin-right: 15px;
  }

  i.fa-regular.fa-user {
    margin-right: 9px;
  }

  i.fa-solid.fa-car-side {
    margin-right: 10px;
  }

  i.fa-solid.fa-wrench {
    margin-right: 13px;
  }

  i.fa-solid.fa-receipt {
    margin-right: 17px;
  }

  i.fa-solid.fa-credit-card {
    margin-right: 12px;
  }

  i.fa-solid.fa-calculator {
    margin-right: 16px;
  }

  i.fa-solid.fa-tag {
    margin-right: 10px;
  }

  i.fa-solid.fa-clipboard-check {
    margin-right: 12px;
  }

  i.fa-solid.fa-envelope-open-text {
    margin-right: 12px;
  }

  i.fa-solid.fa-puzzle-piece {
    margin-right: 12px;
  }

  i.fa-solid.fa-code-branch {
    margin-right: 13px;
  }

  i.fa-solid.fa-file-lines {
    margin-right: 13px;
  }

  i.fa-solid.fa-gear {
    margin-right: 11px;
  } */

  .margin-right-10px {
    margin-right: 10px;
  }

  img.logout_img {
    margin-right: 5px;
  }

  @media (min-width: 280px) and (max-width: 540px) {

    .nav-sm .nav.child_menu li.active,
    .nav-sm .nav.side-menu li.active-sm {
      border-right: transparent;
    }

    /* .nav-sm .nav.side-menu li a i {
    font-size: 25px !important;
    text-align: center;
    width: 100% !important;
    margin-bottom: 5px;
} */
    .dropdown:hover {
      background-color: #FFFFFF;
      color: #454545;
      width: 72px;
    }

    i.fa-solid.fa-sliders {
      margin-left: -13px;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #FFEFE6;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
      z-index: 1;
      inset: 0px 324px auto;
      height: auto;
      width: 160px;
      padding-left: 1px;
      margin-left: -254px;
    }

    .nav-sm .nav.side-menu li a {
      text-align: left !important;
      font-weight: 400;
      font-size: 10px;
      padding: 10px 5px;
    }

    i.fa-regular.fa-user {
      margin-left: -14px;
    }

    i.fa-solid.fa-car-side {
      margin-left: -11px;
    }

    i.fa-solid.fa-credit-card {
      margin-left: -10px;
    }

    i.fa-solid.fa-calculator {
      margin-left: -12px;
    }

    i.fa-solid.fa-clipboard-check {
      margin-left: -4px;
    }
  }

  @media (min-width: 768px) and (max-width: 912px) {
    i.fa-solid.fa-sliders {
      margin-left: -12px;
    }

    .dropdown:hover {
      background-color: #FFFFFF;
      color: #454545;
      width: 70px;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #FFEFE6;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
      z-index: 1;
      inset: 0px 70px auto;
      height: auto;
      width: 160px;
    }

    .nav-sm .nav.side-menu li a {
      text-align: left !important;
      /* font-weight: 400;
    font-size: 10px;
    padding: 10px 5px; */
    }

    i.fa-regular.fa-user {
      margin-left: -12px;
    }

    i.fa-solid.fa-car-side {
      margin-left: -12px;
    }

    i.fa-solid.fa-credit-card {
      margin-left: -12px;
    }

    i.fa-solid.fa-calculator {
      margin-left: -12px;
    }
  }

  @media (min-width: 1024px) and (max-width: 1280px) {
    i.fa-solid.fa-sliders {
      margin-left: 0px;
    }

    .dropdown:hover {
      background-color: #FFFFFF;
      color: #454545;
      width: 72px;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #FFEFE6;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
      z-index: 1;
      inset: 0px 240px auto;
      height: auto;
      width: 222px;
      padding-left: 8px;
    }
  }
   
    button {
      padding: 10px 15px;
      cursor: pointer;
      border: none;
      background-color: #ddd;
      border-radius: 5px;
      font-size: 14px;
      transition: all 0.3s;
    }
    button.active {
      background-color: #007bff;
      color: white;
    }
    .canvas-container {
      position: relative;
      display: inline-block;
    }
    canvas {
      border: 1px solid #bbb;
      position: absolute;
      top: 0;
      left: 0;
      cursor: crosshair;
    }
    #backgroundCanvas {
      z-index: 1; /* Base layer for the car image */
    }
    #overlayCanvas {
      z-index: 2; /* Top layer for marking */
    }

#dentBtn.active {
  background-color: yellow;  
  color: white;
}

#scratchBtn.active {
  background-color: green;  
  color: white;
}

#breakBtn.active {
  background-color: red;  
  color: white;
}
modal-content.modal-body-data.modelHeaderwidth {
    width: 342px !important;
    border-radius: 8px 8px 0px 0px !important;
}

    .modal-dialog.modal-lg.custommodal-lg {
    margin-top: 77px;
    float: inline-end;
}

.controls button {
    margin: 3px;
    border-radius: 8px;
}

.controls {
    margin: 9px;
}

textarea#w3review {
    width: 100%;
}

</style>

<head>
  <meta content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link rel="icon" href="<?php echo e(URL::asset('fevicol.png')); ?>" type="image/gif" sizes="16x16">
  <title><?php echo e(getNameSystem()); ?></title>

  <!-- Bootstrap -->
  <link href="<?php echo e(URL::asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <!-- Font Awesome  V6.1.1-->
  <link href="<?php echo e(URL::asset('vendors/font-awesome/css/fontawesome.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('vendors/font-awesome/css/all.min.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- NProgress -->
  <link href="<?php echo e(URL::asset('vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">

  <link href="<?php echo e(URL::asset('vendors/select2/css/select2.min.css')); ?>" rel="stylesheet">


  <!-- FullCalendar V5.11.0 -->
  <link href="<?php echo e(URL::asset('vendors/fullcalendar/lib/main.min.css')); ?>" rel="stylesheet">

  <!-- bootstrap-daterangepicker -->
  
  
  <link href="<?php echo e(URL::asset('vendors/bootstrap-date-time-picker/bootstrap5/css/bootstrap-datetimepicker.css')); ?>" rel="stylesheet">
  
  <!-- dropify CSS -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('vendors/dropify/css/dropify.min.css')); ?>">

  <!-- Custom Theme Style -->
  <link href="<?php echo e(URL::asset('build/css/custom.min.css')); ?> " rel="stylesheet">

  
  <script src="<?php echo e(URL::asset('vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>" defer="defer"></script>
  <script src="<?php echo e(URL::asset('vendors/datatables.net-buttons/js/buttons.bootstrap.min.js')); ?>" defer="defer"></script>
  <script src="<?php echo e(URL::asset('vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?>" defer="defer"></script>
  <script src="<?php echo e(URL::asset('vendors/datatables.net-buttons/js/buttons.print.min.js')); ?>" defer="defer"></script>
  <script src="<?php echo e(URL::asset('vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')); ?>" defer="defer"></script>
  <script src="<?php echo e(URL::asset('vendors/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>" defer="defer"></script>
  <script src="<?php echo e(URL::asset('vendors/datatables.net-scroller/js/scroller.dataTables.min.js')); ?>" defer="defer"></script>
  <script src="<?php echo URL::asset('public/vendor/pdfmake/js/vfs_fonts.min.js'); ?>"></script>
  <script src="<?php echo URL::asset('public/vendor/pdfmake/js/pdfmake.min.js'); ?>"></script>
  <script src="<?php echo URL::asset('public/vendor/pdfmake/js/Roboto.min.js'); ?>"></script>

  <!-- Own Theme Style -->
  <link href="<?php echo e(URL::asset('build/css/own.css')); ?> " rel="stylesheet">


  <!-- Our Custom stylesheet -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('public/css/responsive_styles.css')); ?>">

  <!-- MoT Custom stylesheet -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('public/css/custom_mot_styles.css')); ?>">
  <!-- Datatables -->
  <!-- <link href="<?php echo e(URL::asset('https://code.jquery.com/jquery-3.5.1.js')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js')); ?>" rel="stylesheet"> -->

  <link href="<?php echo e(URL::asset('vendors/datatable/jquery-3.5.1.js')); ?>" type="text/js" rel="stylesheet">
  <link href="<?php echo e(URL::asset('vendors/datatable/jquery.dataTables.min.js')); ?>" type="text/js" rel="stylesheet">
  <link href="<?php echo e(URL::asset('vendors/datatable/dataTables.bootstrap5.min.js')); ?>" type="text/js" rel="stylesheet">
  <!-- Datatables -->

  <!-- AutoComplete CSS -->
  <link href="<?php echo e(URL::asset('build/css/themessmoothness.css')); ?>" rel="stylesheet">
  <!-- Multiselect CSS -->
  <link href="<?php echo e(URL::asset('build/css/multiselect.css')); ?>" rel="stylesheet">

  <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>

  <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('public/css/google_api_font.css')); ?>">
  <?php if(getValue() == 'rtl'): ?>
  <link href="<?php echo URL::asset('build/css/bootstrap-rtl.min.css'); ?>" rel="stylesheet" id="rtl" />
  <?php else: ?>
  <?php endif; ?>

  <style>
    @media print {
      .noprint {
        display: none
      }
    }
  </style>
  <!-- colorpicker links -->
  <!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.3.3/css/bootstrap-colorpicker.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.3.3/js/bootstrap-colorpicker.min.js"></script>

</head>
<?php
$langcode = getLangCode();

$baseUrl = url('/');
$currentUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
$currentRoute = str_replace($baseUrl, "", $currentUrl);
?>

<body id="app-layout" class="nav-md <?php echo getValue(); ?>">
  <div class="container body">
    <div class="main_container">
      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">
          <div class="navbar nav_title d-none d-sm-block LogoMenuIcon py-0" style="border: 0;">
            <a href="<?php echo url('/'); ?>" class="site_title mb-0">
              <img src="<?php echo e(URL::asset('public/general_setting/' . getLogoSystem())); ?>" class="profilepic">
            </a>
          </div>

          <div class="clearfix"></div>

          <!-- sidebar menu -->
          <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
              <ul class="nav side-menu">
                <?php if(Request::is('domain')): ?>
                <li class="w-100 active"><a href="<?php echo url('/domain'); ?>"><i class="fa-solid fa-gear margin-right-10px"></i><?php echo e(trans('License Settings')); ?></a></li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/'];
                ?>

                <!-- <img src="<?php echo e(URL::asset('public/img/icons/dashboard.png')); ?>" > -->
                <li class=<?php echo e(in_array($currentRoute,$inventoryRoutes) ? 'active' : ''); ?>><a href="<?php echo url('/'); ?>"><i class="fa-solid fa-house margin-right-10px"></i><?php echo e(trans('message.Dashboard')); ?>

                  </a></li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['supplier_view', 'product_view', 'purchase_view', 'stock_view'])): ?>
                <?php
                $inventoryRoutes = ['/supplier/list','/product/list','/purchase/list','/stoke/list','/supplier/add','/product/add','/purchase/add','/stoke/add','/supplier/list/edit/'];
                ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/supplier/list/') || Str::startsWith($currentRoute, '/product/list/edit/') || Str::startsWith($currentRoute, '/purchase/list/edit/') ? 'active' : ''); ?>">

                  <div class="dropdown w-100">
                    <a href="#"><i class="fa-solid fa-sliders margin-right-10px"></i> <?php echo e(trans('message.Inventory')); ?><span class="fa fa-chevron-right dropdown-right-icon icon"> </span></a>
                    <div class="dropdown-content">
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier_view')): ?>
                      <a href="<?php echo url('/supplier/list'); ?>"><?php echo e(trans('message.Supplier')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_view')): ?>
                      <a href="<?php echo url('/product/list'); ?>"><?php echo e(trans('message.Product')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase_view')): ?>
                      <a href="<?php echo url('/purchase/list'); ?>"><?php echo e(trans('message.Purchase')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock_view')): ?>
                      <a href="<?php echo url('/stoke/list'); ?>"><?php echo e(trans('message.Stock')); ?></a>
                      <?php endif; ?>
                    </div>
                  </div>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['customer_view', 'employee_view', 'supportstaff_view', 'accountant_view', 'branchAdmin_view'])): ?>
                <?php
                $inventoryRoutes = ['/customer/list','/employee/list','/supportstaff/list','/accountant/list','/branchadmin/list','/customer/add','/employee/add','/supportstaff/add','/accountant/add','/branchadmin/add'];
                ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/customer/list/') || Str::startsWith($currentRoute, '/employee/view/') || Str::startsWith($currentRoute, '/employee/edit/') || Str::startsWith($currentRoute, '/supportstaff/list/') || Str::startsWith($currentRoute, '/accountant/list/') || Str::startsWith($currentRoute, '/branchadmin/list/') ? 'active' : ''); ?>">

                  <div class="dropdown w-100">
                    <a href="#"><i class="fa-regular fa-user margin-right-10px"></i> <?php echo e(trans('message.Users')); ?><span class="fa fa-chevron-right dropdown-right-icon icon"> </span></a>
                    <div class="dropdown-content dropdown-content-user">
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_view')): ?>
                      <a href="<?php echo url('/customer/list'); ?>"><?php echo e(trans('message.Customers')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee_view')): ?>
                      <a href="<?php echo url('/employee/list'); ?>"><?php echo e(trans('message.Employees')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supportstaff_view')): ?>
                      <a href="<?php echo url('/supportstaff/list'); ?>"><?php echo e(trans('message.Support Staff')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accountant_view')): ?>
                      <a href="<?php echo url('/accountant/list'); ?>"><?php echo e(trans('message.Accountant')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branchAdmin_view')): ?>
                      <a href="<?php echo url('/branchadmin/list'); ?>"><?php echo e(trans('message.Branch Admin')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sparepartvendor_view')): ?>
                      <a href="<?php echo url('/sparepartvendor/list'); ?>"><?php echo e(trans('message.Spare Part Vendor')); ?></a>
                      <?php endif; ?>

                    </div>
                  </div>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['vehicle_view', 'vehicletype_view', 'vehiclebrand_view', 'colors_view'])): ?>
                <?php
                $inventoryRoutes = ['/vehicle/list','/vehicletype/list','/vehiclebrand/list','/color/list','/vehicle/add','/vehicletype/vehicletypeadd','/vehiclebrand/add','/color/add'];
                ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/vehicle/list') || Str::startsWith($currentRoute, '/vehicletype/list/') || Str::startsWith($currentRoute, '/vehiclebrand/list/') || Str::startsWith($currentRoute, '/color/list/edit/') ? 'active' : ''); ?>">

                  <div class="dropdown w-100">
                    <a href="#"><i class="fa-solid fa-car-side margin-right-10px"></i><?php echo e(trans('message.Vehicles')); ?><span class="fa fa-chevron-right dropdown-right-icon icon"> </span></a>
                    <div class="dropdown-content dropdown-content-vehicle ">
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle_view')): ?>
                      <a href="<?php echo url('/vehicle/list'); ?>"><?php echo e(trans('message.List Vehicle')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicletype_view')): ?>
                      <a href="<?php echo url('/vehicletype/list'); ?>"><?php echo e(trans('message.List Vehicle Type')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehiclebrand_view')): ?>
                      <a href="<?php echo url('/vehiclebrand/list'); ?>"><?php echo e(trans('message.List Vehicle Brand')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehiclemodel_view')): ?>
                      <a href="<?php echo url('/vehicalmodel/list'); ?>"><?php echo e(trans('message.List Vehicle Model')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('colors_view')): ?>
                      <a href="<?php echo url('/color/list'); ?>"><?php echo e(trans('message.Colors')); ?></a>
                      <?php endif; ?>
                    </div>
                  </div>
                </li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/service/list','/service/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_view')): ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/service/list/') ? 'active' : ''); ?>"><a href="<?php echo url('/service/list'); ?>"><i class="fa-solid fa-wrench margin-right-10px"></i><?php echo e(trans('message.Services')); ?></a></li>
                <?php endif; ?>


                  <?php
                $inventoryRoutes = ['/service/list','/service/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_view')): ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/service/list/') ? 'active' : ''); ?>"><a href="<?php echo url('/service/list'); ?>"><i class="fa-solid fa-wrench margin-right-10px"></i><?php echo e(trans('message.Tools')); ?></a></li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/quotation/list','/quotation/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotation_view')): ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/quotation/list/') ? 'active' : ''); ?>">
                  <a href="<?php echo url('/quotation/list'); ?>"><i class="fa-solid fa-file-invoice-dollar margin-right-10px"></i> <?php echo e(trans('message.Quotation')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/invoice/list','/invoice/add','/invoice/sale_part'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_view')): ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/invoice/') ? 'active' : ''); ?>"><a href="<?php echo url('/invoice/list'); ?>"><i class="fa-solid fa-receipt margin-right-10px"></i> <?php echo e(trans('message.Invoices')); ?></a></li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['jobcard_view', 'gatepass_view'])): ?>
                <?php
                $inventoryRoutes = ['/jobcard/list','/gatepass/list','/gatepass/add'];
                ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/jobcard/') || Str::startsWith($currentRoute, '/gatepass/') ? 'active' : ''); ?>">
                  <div class="dropdown w-100">
                    <a href="#"><i class="fa-solid fa-credit-card margin-right-10px"></i><?php echo e(trans('message.Job Card')); ?><span class="fa fa-chevron-right dropdown-right-icon icon"></span></a>
                    <div class="dropdown-content dropdown-content-jobcard">
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jobcard_view')): ?>
                      <a href="<?php echo url('/jobcard/list'); ?>"><?php echo e(trans('message.Job Card')); ?></a>
                      <?php endif; ?>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gatepass_view')): ?>
                      <a href="<?php echo url('/gatepass/list'); ?>"><?php echo e(trans('message.Gate Pass')); ?></a>
                      <?php endif; ?>
                    </div>
                  </div>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['jobcard_view', 'gatepass_view'])): ?>
                <?php
                $inventoryRoutes = ['/jobcard/list','/gatepass/list','/gatepass/add'];
                ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/jobcard/') || Str::startsWith($currentRoute, '/gatepass/') ? 'active' : ''); ?>">
                  <div class="dropdown w-100">
                    <a href="#"><i class="fa-solid fa-credit-card margin-right-10px"></i><?php echo e(trans('message.Job Card')); ?><span class="fa fa-chevron-right dropdown-right-icon icon"></span></a>
                    <div class="dropdown-content dropdown-content-jobcard">
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jobcard_view')): ?>
                      <a href="<?php echo e(route('newjobcard.list')); ?>"><?php echo e(trans('message.Job Card')); ?></a>
                      <?php endif; ?>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gatepass_view')): ?>
                      <a href="<?php echo url('/gatepass/list'); ?>"><?php echo e(trans('message.Gate Pass')); ?></a>
                      <?php endif; ?>
                    </div>
                  </div>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['taxrate_view', 'paymentmethod_view', 'income_view', 'expense_view'])): ?>
                <?php
                $inventoryRoutes = ['/taxrates/list','/payment/list','/income/list','/expense/list','/taxrates/add','/payment/add','/income/add','/income/month_income','/expense/add','/expense/month_expense'];
                ?>
                <li class="<?php echo e(in_array($currentRoute, $inventoryRoutes) || Str::startsWith($currentRoute, '/taxrates/') || Str::startsWith($currentRoute, '/payment/') || Str::startsWith($currentRoute, '/income/') || Str::startsWith($currentRoute, '/expense/') ? 'active' : ''); ?>">
                  <div class="dropdown w-100">
                    <a href="#"><i class="fa-solid fa-calculator margin-right-10px"></i> <?php echo e(trans('message.Accounts')); ?><span class="fa fa-chevron-right dropdown-right-icon icon"></span></a>
                    <div class="dropdown-content">
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('taxrate_view')): ?>
                      <a href="<?php echo url('/taxrates/list'); ?>"><?php echo e(trans('message.List Tax Rates')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('paymentmethod_view')): ?>
                      <a href="<?php echo url('/payment/list'); ?>"><?php echo e(trans('message.List Payment Method')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('income_view')): ?>
                      <a href="<?php echo url('/income/list'); ?>"><?php echo e(trans('message.Income')); ?></a>
                      <?php endif; ?>

                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_view')): ?>
                      <a href="<?php echo url('/expense/list'); ?>"><?php echo e(trans('message.Expenses')); ?></a>
                      <?php endif; ?>
                    </div>
                  </div>
                </li>
                <?php endif; ?>

                <!-- <?php
                $inventoryRoutes = ['/sales/list','/sales/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales_view')): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) || Str::startsWith($currentRoute, '/sales/') ? 'active' : ''); ?>"><a href="<?php echo url('/sales/list'); ?>"><i class="fa-solid fa-tag"></i>
                    <?php if(Auth::user()->role == 'Customer'): ?>
                    <?php echo e(trans('message.Vehicle Purchased')); ?>

                    <?php else: ?>
                    <?php echo e(trans('message.Vehicle Sells')); ?>

                    <?php endif; ?>
                  </a> </li>
                <?php endif; ?> -->

                
                <?php
                  $inventoryRoutes = ['/purchase-spare-part/list','/purchase-spare-part/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('salespart_view')): ?>
                    <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) || Str::startsWith($currentRoute, '/purchase-spare-part/') ? 'active' : ''); ?>"><a href="<?php echo e(route('purchase_spare_part.list')); ?>"><i class="fa-solid fa-tag margin-right-10px"></i> <?php echo e(trans('Purchase Spare Parts')); ?> </a> </li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/rto/list','/rto/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rto_view')): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) || Str::startsWith($currentRoute, '/rto/') ?  'active' : ''); ?>"><a href="<?php echo url('/rto/list'); ?>"><i class="fa-solid fa-clipboard-check margin-right-10px"></i> <?php echo e(trans('message.Compliance')); ?></a>
                </li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/report/salesreport','/report/servicereport','/report/productreport','/report/productuses','/report/servicebyemployee'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report_view')): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes)  || Str::startsWith($currentRoute, '/report/')? 'active' : ''); ?>"><a href="<?php echo url('/report/servicereport'); ?>"><i class="fa-solid fa-chart-line margin-right-10px"></i><?php echo e(trans('message.Reports')); ?>

                  </a></li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('emailtemplate_view')): ?>
                <li class="w-100"><a href="<?php echo url('/mail/mail'); ?>"><i class="fa-solid fa-envelope-open-text margin-right-10px"></i><?php echo e(trans('message.Email Templates')); ?></a></li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/setting/custom/list','/setting/custom/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customfield_view')): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) || Str::startsWith($currentRoute, '/setting/custom/') ? 'active' : ''); ?>"><a href="<?php echo url('/setting/custom/list'); ?>"><i class="fa-solid fa-puzzle-piece margin-right-10px"></i><?php echo e(trans('message.Custom Fields')); ?></a> </li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/observation/list','/observation/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('observationlibrary_view')): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) ? 'active' : ''); ?>"><a href="<?php echo url('/observation/list'); ?>"><i class="fa-solid fa-file-lines margin-right-10px"></i> <?php echo e(trans('message.Observation library')); ?></a></li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/notes/list','/notes/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notes_view')): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) ? 'active' : ''); ?>"><a href="<?php echo url('/notes/list'); ?>"><i class="fa-solid fa-pen-to-square margin-right-10px"></i> <?php echo e(trans('message.Notes')); ?></a></li>
                <?php endif; ?>

                <?php
                $inventoryRoutes = ['/branch/list','/branch/add'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branch_view')): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) || Str::startsWith($currentRoute, '/branch/') ? 'active' : ''); ?>"><a href="<?php echo url('/branch/list'); ?>"><i class="fa-solid fa-code-branch margin-right-10px"></i> <?php echo e(trans('message.Branch')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessory_view')): ?>
                <li>
                  <a href="<?php echo e(route('accessory.list')); ?>">
                    <i class="fa-solid fa-toolbox margin-right-10px"></i><?php echo e(trans('Accessories')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('parts_view')): ?>
                <li>
                  <a href="<?php echo e(route('sparepart.list')); ?>">
                    <i class="fa-solid fa-cogs margin-right-10px"></i><?php echo e(trans('Parts')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <!-- New "Tools" option added below "Parts" -->

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tools_view')): ?>
                <li>
                  <a href="<?php echo e(route('tool.list')); ?>">
                    <i class="fa-solid fa-wrench margin-right-10px"></i><?php echo e(trans('Tools')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lubricants_view')): ?>
                <li>
                  <a href="<?php echo e(route('lubricant.list')); ?>">
                    <i class="fa-solid fa-oil-can margin-right-10px"></i><?php echo e(trans('Lubricants')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('units_view')): ?>
                <li>
                  <a href="<?php echo e(route('unit.list')); ?>">
                    <i class="fa-solid fa-oil-can margin-right-10px"></i><?php echo e(trans('Units')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categories_view')): ?>
                <li>
                  <a href="<?php echo e(route('category.list')); ?>">
                    <i class="fa-solid fa-oil-can margin-right-10px"></i><?php echo e(trans('Categories')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_view')): ?>
                <li>
                  <a href="<?php echo e(route('order.list')); ?>">
                    <i class="fa-solid fa-oil-can margin-right-10px"></i><?php echo e(trans('Order')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock')): ?>
                <li>
                  <a href="<?php echo e(route('stock.list')); ?>">
                    <i class="fa-solid fa-oil-can margin-right-10px"></i><?php echo e(trans('Stock')); ?>

                  </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock')): ?>
                <li>
                  <a href="<?php echo e(route('stock_history.list')); ?>">
                    <i class="fa-solid fa-oil-can margin-right-10px"></i><?php echo e(trans('Stock History')); ?>

                  </a>
                </li>
                <?php endif; ?>


                <?php
                $inventoryRoutes = ['/setting/general_setting/list','/setting/timezone/list','/setting/accessrights/show','/setting/hours/list','/setting/stripe/list','/branch_setting/list'];
                ?>
                <?php if(getActiveAdmin(Auth::User()->id) == 'yes'): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) ? 'active' : ''); ?>"><a data-toggle="" data-placement="top" href="<?php echo url('/setting/general_setting/list'); ?>" title="<?php echo e(trans('message.Settings')); ?>"> <i class="fa-solid fa-gear margin-right-10px"></i><?php echo e(trans('message.Settings')); ?></a></li>
                <?php else: ?>
                <?php if(Gate::allows('generalsetting_view')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('generalsetting_view')): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) ? 'active' : ''); ?>"><a data-toggle="" data-placement="top" href="<?php echo url('/setting/general_setting/list'); ?>" title="<?php echo e(trans('message.Settings')); ?>"> <i class="fa-solid fa-gear margin-right-10px"></i><?php echo e(trans('message.Settings')); ?></a></li>
                <?php endif; ?>
                <?php else: ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('timezone_view')): ?>
                <li class="<?php echo e(in_array($currentRoute,$inventoryRoutes) ? 'active' : ''); ?>"><a data-toggle="" data-placement="top" href="<?php echo url('/setting/timezone/list'); ?>" title="<?php echo e(trans('message.Settings')); ?>"> <i class="fa-solid fa-gear margin-right-10px"></i><?php echo e(trans('message.Settings')); ?></a></li>
                <?php endif; ?>
                <?php endif; ?>
                <?php endif; ?>
                <li>
                  <a class="logoutConfirm margin-right-10px"><i class="fa fa-power-off" aria-hidden="true"></i><?php echo e(trans('message.Logout')); ?></a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                  </form>
                  <!-- <a title="<?php echo e(trans('message.Logout')); ?>" href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                  <i class="fa fa-power-off" aria-hidden="true"></i><?php echo e(trans('message.Logout')); ?>

                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                  </form>
                </a> -->
                </li>
              </ul>
              <nav aria-label="Page navigation example">

            </div>
          </div>

          <!-- /sidebar menu -->

        </div>
      </div>

      <!-- top navigation -->
      <div class="top_nav position-relative">


 <div class="modal fade" id="bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg custommodal-lg">
            <div class="modal-content modal-body-data modelHeaderwidth" style="width: 320px !important;border-radius: 8px 8px 0px 0px !important;">
               
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->



 <div class="modal fade" id="bs-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-xl custommodal-xl">
            <div class="modal-content modal-body-data">
               
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->


        <!-- /top navigation -->
        <?php echo $__env->yieldContent('content'); ?>
        <footer class="footerforallpage bottom-0 bg-white text-center" id="footerforid">
          <span class="footerbottom me-3"><?php echo e(trans('© Copyright 2024 | Garage Master  | All Rights Reserved')); ?></span>
        </footer>
      </div>
    </div>
  </div>

  <!-- jQuery -->
  <script src="<?php echo e(URL::asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>

  <!-- <script src="<?php echo e(URL::asset('build/js/jquery-ui.js')); ?>" defer="defer"></script> -->


  <!-- Bootstrap -->
  <script src="<?php echo e(URL::asset('build/js/popper.min.js')); ?>" defer="defer"></script>

  

  <script src="<?php echo e(URL::asset('vendors/bootstrap/dist/js/bootstrap.bundle.js')); ?>" defer="defer"></script>


  <!-- NProgress -->
  <script src="<?php echo e(URL::asset('vendors/nprogress/nprogress.js')); ?>" defer="defer"></script>

  <!-- DateJS for theme default js-->
  <script src="<?php echo e(URL::asset('vendors/DateJS/build/date.js')); ?>" defer="defer"></script>

  <!-- Custom Theme Scripts -->
  <script src="<?php echo e(URL::asset('build/js/custom.min.js')); ?>" defer="defer"></script>
  <script src="<?php echo e(URL::asset('vendors/sweetalert/dist/sweetalert.min.js')); ?>" defer="defer"></script>

  <!-- <script src="https://cdn.datatables.net/v/bs5/jqc-1.12.4/dt-1.13.4/datatables.min.js"></script> -->
  <script type="text/javascript" src="<?php echo e(URL::asset('vendors/datatable/datatables.min.js')); ?>"></script>


  <!-- dropify scripts-->
  <script src="<?php echo e(URL::asset('vendors/dropify/js/dropify.min.js')); ?>" defer="defer"></script>

  <!-- bootstrap-daterangepicker -->
  <script src="<?php echo e(URL::asset('vendors/moment/moment.min.js')); ?>" defer="defer"></script>
  
  <script src="<?php echo e(URL::asset('vendors/bootstrap-date-time-picker/bootstrap5/js/bootstrap-datetimepicker.min.js')); ?>" defer="defer"></script>
  <script src="<?php echo e(URL::asset('/vendors/bootstrap-date-time-picker/bootstrap5/js/locales/bootstrap-datetimepicker.' . getLangCode() . '.js')); ?>" defer="defer"></script>

  

  <!-- Filter  -->
  <script src="<?php echo e(URL::asset('vendors/jszip/dist/jszip.min.js')); ?>" defer="defer"></script>

  <!-- Autocomplete Js  -->
  <script src="<?php echo e(URL::asset('build/js/jquery.circliful.min.js')); ?>" defer="defer"></script>

  <!-- Multiselect Js  -->
  <script src="<?php echo e(URL::asset('build/js/bootstrap-multiselect.js')); ?>" defer="defer"></script>
  <script src="<?php echo e(URL::asset('vendors/select2/js/select2.min.js')); ?>" type='text/javascript' defer="defer"></script>

  <!-- For form field validate Using Proengsoft -->
  <script type="text/javascript" src="<?php echo e(URL::asset('build/jquery-validate/1.19.2/jquery.validate.min.js')); ?>"></script>


  <script type="text/javascript">
    $(document).ready(function() {
      $('form').bind("keypress", function(e) {
        if (e.keyCode == 13) {
          e.preventDefault();
          return false;
        }
      });

      $('body').on('click', '.logoutConfirm', function() {
        var msg1 = "<?php echo e(trans('message.Are You Sure?')); ?>";
        var msg2 = "<?php echo e(trans('message.You will be logged out!')); ?>";
        var msg3 = "<?php echo e(trans('message.Cancel')); ?>";
        var msg4 = "<?php echo e(trans('message.Yes')); ?>";

        swal({
          title: msg1,
          text: msg2,
          icon: 'warning',
          cancelButtonColor: '#C1C1C1',
          buttons: [msg3, msg4],
          dangerMode: true,
        }).then((willDelete) => {
          if (willDelete) {
            event.preventDefault();
            document.getElementById('logout-form').submit();
          }
        });
      });
    });

    var csrf_token = document.querySelector("meta[name='csrf-token']").getAttribute("content");

    function csrfSafeMethod(method) {
      // these HTTP methods do not require CSRF protection
      return (/^(GET|HEAD|OPTIONS)$/.test(method));
    }
    var o = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function() {
      var res = o.apply(this, arguments);
      var err = new Error();
      if (!csrfSafeMethod(arguments[0])) {
        this.setRequestHeader('anti-csrf-token', csrf_token);
      }
      return res;
    };
  </script>

  <!-- Delete multiple rows -->
  <script src="<?php echo e(URL::asset('public/js/custom/accessrights/deletemultiple.js')); ?>"></script>

  <!-- Add multiple notes -->
  <script src="<?php echo e(URL::asset('public/js/custom/accessrights/notes.js')); ?>"></script>

  <!-- For scroll active tab -->
  <script>
    var activeElement = document.querySelector('.nav-tabs .nav-link.active');

    if (activeElement) {
      activeElement.scrollIntoView({
        behavior: 'smooth',
        block: 'end'
      });
    }

    $(document).ready(function() {
      var csrfToken = $('meta[name="csrf-token"]').attr('content');
      var checkedCount = 0;
      var checkboxes = $('input[name="chk"]');
      var totalRows = $('table tbody tr').length;
      var selectAll = $('input[name="selectAll"]');


      $('#select-all-btn').click(function() {
        var checkboxes = $('input[name="chk"]');
        checkboxes.prop('checked', !checkboxes.prop('checked'));
      });

      checkboxes.change(function() {
        // Update checkedCount every time a checkbox changes
        checkedCount = checkboxes.filter(':checked').length;
        if (checkedCount === totalRows) {
          selectAll.prop('checked', true); // Set the "Select All" checkbox to true
        } else {
          selectAll.prop('checked', false); // Set the "Select All" checkbox to false if not all checkboxes are checked
        }
      });

      $('#delete-selected-btn').click(function() {
        var selectedIds = [];
        var deleteUrl = $(this).data('url');

        $('input[name="chk"]:checked').each(function() {
          selectedIds.push($(this).closest('tr').data('user-id'));
        });

        if (selectedIds.length === 0) {
          swal({
            title: "<?php echo e(trans('message.Please select atleast one record')); ?>",
            icon: 'warning',
            button: "<?php echo e(trans('message.OK')); ?>",
            dangerMode: true,
          });
          return;
        } else {
          var msg1 = "<?php echo e(trans('message.Are You Sure?')); ?>";
          var msg2 = "<?php echo e(trans('message.You will not be able to recover this data afterwards!')); ?>";
          var msg3 = "<?php echo e(trans('message.Cancel')); ?>";
          var msg4 = "<?php echo e(trans('message.Yes, delete!')); ?>";

          swal({
            title: msg1,
            text: msg2,
            icon: 'warning',
            cancelButtonColor: '#C1C1C1',
            buttons: [msg3, msg4],
            dangerMode: true,
          }).then((willDelete) => {
            if (willDelete) {
              $.ajax({
                url: deleteUrl,
                method: 'POST',
                data: {
                  _token: csrfToken,
                  ids: selectedIds
                },
                success: function(response) {
                  selectedIds.forEach(function(id) {
                    $('tr[data-user-id="' + id + '"]').remove();
                  });
                  location.reload();
                },
                error: function() {
                  alert('An error occurred while deleting selected rows.');
                }
              });
            }
          });
        }
      });
    });
  </script>

</body>

</html><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/layouts/app.blade.php ENDPATH**/ ?>