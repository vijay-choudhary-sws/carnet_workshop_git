<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <style type="text/css">
    <?php if(getLangCode()==='hi'): ?>body,
    p,
    td,
    div,
    th {
      font-family: freeserif;
    }

    <?php elseif(getLangCode()==='gu'): ?> body,
    p,
    td,
    div,
    th {
      font-family: freeserif;
    }

    <?php elseif(getLangCode()==='ja'): ?> body,
    p,
    td,
    div,
    th {
      font-family: freeserif;
    }

    <?php elseif(getLangCode()==='zhcn'): ?> body,
    p,
    td,
    div,
    th {
      font-family: DejaVu Sans, freeserif; // not working
    }

    <?php elseif(getLangCode()==='th'): ?> body,
    p,
    td,
    div,
    th,
    strong {
      font-family: bitstreamcyberbit, freeserif, garuda, norasi, quivira;
    }

    <?php elseif(getLangCode()==='mr'): ?> body,
    p,
    td,
    div,
    th {
      font-family: freeserif;
    }

    <?php elseif(getLangCode()==='ta'): ?> body,
    p,
    td,
    div,
    th,
    strong {
      font-family: ind_ta_1_001, freeserif;
    }

    <?php else: ?> body,
    p,
    td,
    div,
    th,
    strong {
      font-family: freeserif;
    }

    <?php endif; ?>
  </style>
</head>
<style>
  body {
    font-family: 'Helvetica';
    font-style: normal;
    font-weight: normal;
    color: #333;
  }

  .itemtable th,
  td {
    padding: 0px 14px 6px 14px;
    font-size: 14px;
  }

  #imggrapish {
    margin-top: -50px;
    margin-left: 5px;
  }

  page[size="A4"] {
    background: white;
    width: 21cm;
    height: 29.7cm;
    display: block;
    margin: 0 auto;
    margin-bottom: 0.5cm;
  }

  .mail_img {
    width: 12px;
  }

  .addr_img {
    width: 10px;
  }

  .user_img {
    width: 14px;
    height: 12px;
  }

  .phoneimg {
    width: 14px;
    height: 12px;
    /* margin-bottom: 2px; */
    margin-right: 1px;
  }

  .invoice_detail {
    line-height: 25px;
    font-size: 14px;
  }

  .system_addr_details {
    line-height: 25px;
    font-size: 14px;
  }

  .customer_details {
    line-height: 25px;
    margin-top: 3px;
  }

  .cust_addr_details {
    line-height: 25px;
  }

  .grand_total_modal_invoice {
    background: #EA6B00;
    color: #FFFFFF;
    margin-left: 55%;
    margin-bottom: 0px;
  }

  @media print {

    body,
    page[size="A4"] {
      margin: 0;
      box-shadow: 0;
    }
  }
</style>

<body>

  <div class="row" id="imggrapish">
    <br>
    <table width="100%" border="0" style="margin:0px 8px 0px 8px; font-family:Poppins;">
      <tr>
        <td align="left">
          <h3 style="font-size:18px;"><?php echo $logo->system_name; ?></h3>
        </td>
      </tr>
    </table>
    <hr />
    <table>
      <tbody>
        <tr class="customer_details">
          <td width="15%" style="vertical-align:top;float:left;" align="left">
            <span style="width:100%;">
              <img src="<?php echo e(base_path()); ?>/public/general_setting/<?php echo $logo->logo_image; ?>" width="230px" height="70px">
            </span>
          </td>
          <td style="width: 45%;" vertical-align:top;">
            <span style="float:right; class=" cust_addr_details">
              <b><img src="<?php echo e(base_path()); ?>/public/img/icons/user_img.png" class="user_img"></b> <?php echo getCustomerName($tbl_invoices->customer_id); ?>
              <br>
              <b><img src="<?php echo e(base_path()); ?>/public/img/icons/Vector (14).png" class="addr_img"></b> <?php echo $customer->address;
                                                                                                      echo ', ';
                                                                                                      echo getCityName("$customer->city_id") != null ? getCityName("$customer->city_id") . ', ' : ''; ?><?php echo getStateName("$customer->state_id,");
                                                                                                                                                                                                        echo ', ';
                                                                                                                                                                                                        echo getCountryName($customer->country_id); ?>
              <br>
              <b><img src="<?php echo e(base_path()); ?>/public/img/icons/phoneimg1.png" class="phoneimg"></b> <?php echo "$customer->mobile_no"; ?>
              <br>
              <b><img src="<?php echo e(base_path()); ?>/public/img/icons/Vector (15).png" class=" mail_img"></b> <?php echo $customer->email; ?>
              <br>
              <b><?php echo e(trans('message.Invoice')); ?> :</b> <?php echo $tbl_invoices->invoice_number; ?>
              <br>
              <b><?php echo e(trans('message.Status :')); ?></b><?php if ($tbl_invoices->payment_status == 0) {
                                                      echo '<span style="color: rgb(255, 0, 0);">' .  trans('message.Unpaid') . '</span>';
                                                    } elseif ($tbl_invoices->payment_status == 1) {
                                                      echo '<span style="color: rgb(255, 165, 0);">' .  trans('message.Partially paid') . '</span>';
                                                    } elseif ($tbl_invoices->payment_status == 2) {
                                                      echo '<span style="color: rgb(0, 128, 0);">' .  trans('message.Full Paid') . '</span>';
                                                    } else {
                                                      echo '<span style="color: rgb(255, 0, 0);">' .  trans('message.Unpaid') . '</span>';
                                                    } ?><br>
              <b><?php echo e(trans('message.Date')); ?> :</b> <?php echo date(getDateFormat(), strtotime($tbl_invoices->date)); ?>
              <br>
              <?php if(($customer->tax_id) != ''): ?>
              <b><?php echo e(trans('message.Tax Id')); ?> :</b>
              <?php echo $customer->tax_id; ?>
              <?php endif; ?>
              <?php if(($tbl_invoices->details) != ''): ?>
              <b><?php echo e(trans('message.Details')); ?> :</b> <?php echo $tbl_invoices->details; ?>
              <?php endif; ?>
            </span>
          </td>

        </tr>
        <tr>
          <td width="50%" style="vertical-align:top;float:left;">
            <span style="float:left; font-size: 14px;" class="system_addr_details">
              <img src="<?php echo e(base_path()); ?>/public/img/icons/Vector (15).png" class="mail_img">
              <?php
              echo '' . $logo->email;
              ?>
              <br>
              <img src="<?php echo e(base_path()); ?>/public/img/icons/phoneimg1.png" class="phoneimg">
              <?php
              echo '' . $logo->phone_number;
              ?>
              <br>
              <div class="col-12 d-flex align-items-start" style="margin-top: 2px;">
                <img src="<?php echo e(base_path()); ?>/public/img/icons/Vector (14).png" class="addr_img">
                <?php
                $taxNumber = $taxName = null;
                if (!empty($service_taxes)) {
                  foreach ($service_taxes as $tax) {

                    if (substr_count($tax, ' ') > 1) {
                      $taxNumberArray = explode(" ", $tax);

                      $taxName = $taxNumberArray[0];
                      $taxNumber = $taxNumberArray[2];
                    }
                  }
                }

                //echo $logo->address ? ', <br>' : '';
                echo $logo->address . ' ';
                echo ' ' . getCityName($logo->city_id);
                echo ', ' . getStateName($logo->state_id);
                echo ', ' . getCountryName($logo->country_id);

                // if ($taxName !== null && $taxNumber !== null) {
                //   echo '<br> ' . $taxName . ':- ' . $taxNumber;
                // }

                ?>
              </div>
            </span>
          </td>

        </tr>
      </tbody>
    </table>

    <hr />
    <table class="table " border="0" width="100%" style="border-collapse:collapse;">
      <thead></thead>

      <tbody class="itemtable">
        <tr>
          <th align="left" style="padding:8px;"><?php echo e(trans('message.Jobcard Number')); ?></th>
          <th align="left" style="padding:8px;"><?php echo e(trans('message.Coupon Number')); ?></th>
          <th align="left" style="padding:8px;"><?php echo e(trans('message.Vehicle Name')); ?></th>
          <th align="left" style="padding:8px;"><?php echo e(trans('message.Number Plate')); ?></th>
          <th align="left" style="padding:8px;"><?php echo e(trans('message.In Date')); ?></th>
          <th align="left" style="padding:8px;"><?php echo e(trans('message.Out Date')); ?></th>
        </tr>

        <tr>
          <td align="left" style="padding:8px;"><?php echo "$tbl_services->job_no"; ?></td>
          <td align="left" style="padding:8px;"><?php if (!empty($job->coupan_no)) {
                                                  echo $job->coupan_no;
                                                } else {
                                                  echo trans('message.Paid Service');
                                                } ?></td>
          <td align="left" style="padding:8px;"><?php if (!empty($job->vehicle_id)) {
                                                  echo getVehicleName($job->vehicle_id);
                                                } ?></td>
          <td align="left" style="padding:8px;"><?php if (!empty($job->vehicle_id)) {
                                                  echo getVehicleNumberPlate($job->vehicle_id);
                                                } ?></td>
          <td align="left" style="padding:8px;"><?php if (!empty($job)) {
                                                  echo $job->in_date;
                                                } ?> </td>
          <td align="left" style="padding:8px;"><?php if (!empty($job)) {
                                                  echo $job->out_date;
                                                } ?> </td>
        </tr>
        <tr>
          <th align="left" style="padding:8px;"><?php echo e(trans('message.Assigned To')); ?></th>
          <th align="left" style="padding:8px;"><?php echo e(trans('message.Repair Category')); ?></th>
          <th align="left" style="padding:8px;"><?php echo e(trans('message.Service Type')); ?></th>
          <th align="left" style="padding:8px;" colspan="3"><?php echo e(trans('message.Details')); ?></th>
        </tr>
        <tr>
          <td align="left" style="padding:8px;"><?php echo getAssignedName($tbl_services->assign_to); ?> </td>
          <td align="left" style="padding:8px;"><?php echo $tbl_services->service_category; ?> </td>
          <td align="left" /* style="padding:8px;"><?php echo $tbl_services->service_type; ?> </td> */
          <td align="left" style="padding:8px;" colspan="3"><?php echo $tbl_services->detail; ?> </td>
        </tr>
      </tbody>
    </table>
    <hr />
    <?php
    if ($tbl_invoices->notes->isEmpty()) {
    } else {
    ?>
      <table class="table table-bordered itemtable" width="100%" border="1" style="border-collapse:collapse;">
        <tbody>
          <tr class="printimg" style=" color:#333;">
            <th align="left" style="padding:8px; font-size:14px;" colspan="2"><?php echo e(trans('message.Notes')); ?></th>
          </tr>
          <?php
          foreach ($tbl_invoices->notes as $key => $note) {
          ?>
            <tr>
              <td align="left" style="padding:8px;">
                <p><strong>Notes By <?php echo e(getUserFullName($note->create_by)); ?> On <?php echo e($note->created_at->setTimezone(Auth::User()->timezone)); ?></strong></p>
                <p><?php echo e($note->notes); ?></p>
              </td>
              <td align="left" style="padding:8px;">
                <strong>
                  <p class="text-start mb-0"><?php echo e(trans('message.Attachments')); ?> :</p>
                </strong>
                <?php
                $attachments = \App\note_attachments::where('note_id', '=', $note->id)->get();
                if ($attachments->isEmpty()) {
                ?>
                  <p class="text-start text-danger"><?php echo e(trans('message.Not Added')); ?> :</p>
                <?php
                } else {
                ?>
                  <p class="text-start text-danger"><?php echo e(count($attachments)); ?> attachment(s)</p>
                <?php } ?>
              </td>
            </tr>
          <?php
          }
          ?>
        </tbody>
      </table>
    <?php
    }
    ?>

    <?php
    $total1 = 0;
    if ($service_pro === []) {
    } else { ?>
      <table class="table table-bordered itemtable" width="100%" border="1" style="border-collapse:collapse;">
        <tbody>
          <tr class="printimg" style=" color:#333;">
            <th align="left" style="padding:8px; font-size:14px;" colspan="8"><?php echo e(trans('message.Observation Charges')); ?></th>
          </tr>
          <tr>
            <th align="left" style="padding:8px; width: 5%;"> # </th>
            <th align="left" style="padding:8px;"><?php echo e(trans('message.Category')); ?></th>
            <th align="left" style="padding:8px;"><?php echo e(trans('message.Observation Point')); ?></th>
            <th align="left" style="padding:8px;"><?php echo e(trans('message.Service Charge')); ?></th>
            <th align="left" style="padding:8px;"><?php echo e(trans('message.Product Name')); ?></th>
            <th align="left" style="padding:8px;"><?php echo e(trans('message.Price')); ?> (<?php echo getCurrencySymbols(); ?>)</th>
            <th align="left" style="padding:8px;"><?php echo e(trans('message.Quantity')); ?> </th>
            <th align="left" style="padding:8px; width: 20%;"><?php echo e(trans('message.Total Price')); ?> (<?php echo getCurrencySymbols(); ?>) </th>
          </tr>


          <?php
          $total1 = 0;
          $i = 1;
          foreach ($service_pro as $service_pros) { ?>
            <br />

            <tr>
              <td align="left" style="padding:8px;"><?php echo $i++; ?></td>
              <td align="left" style="padding:8px;"> <?php echo $service_pros->category; ?></td>
              <td align="left" style="padding:8px;"> <?php echo $service_pros->obs_point; ?></td>
              <td align="left" style="padding:8px;"> <?php echo number_format((float) $service_pros->service_charge, 2); ?></td>
              <td align="left" style="padding:8px;"> <?php echo getProduct($service_pros->product_id); ?></td>
              <td align="left" style="padding:8px;"> <?php echo number_format((float) $service_pros->price, 2); ?></td>
              <td align="left" style="padding:8px;"><?php echo $service_pros->quantity; ?></td>
              <td align="right" style="padding:8px;"><?php echo number_format((float) $service_pros->total_price, 2); ?></td>
              <?php $total1 += number_format((float)$service_pros->total_price, 2); ?>
            </tr>


          <?php } ?>
        </tbody>
      </table>
    <?php
    }
    $total2 = 0;
    $total3 = 0;
    $total4 = 0;
    $i = 1;
    $mot_status = $tbl_services->mot_status;
    if (!empty($service_pro2) || !empty($washbay_data) || $mot_status == 1) {
    ?>
      <br />
      <table class="table table-bordered itemtable" width="100%" border="1" style="border-collapse:collapse;">
        <tbody>
          <tr style="color:#333;">
            <th align="left" style="font-size:14px;padding:8px;" colspan="6"><?php echo e(trans('message.Other Service Charges')); ?></th>
          </tr>
          <tr>
            <th align="left" style="padding:8px; width: 5%;">#</th>
            <th align="left" style="padding:8px;" colspan="2"><?php echo e(trans('message.Charge for')); ?></th>
            <th align="left" style="padding:8px;" colspan="2"><?php echo e(trans('message.Price')); ?> (<?php echo getCurrencySymbols(); ?>)</th>
            <th align="left" style="padding:8px; width: 20%;"><?php echo e(trans('message.Total Price')); ?> (<?php echo getCurrencySymbols(); ?>) </th>
          </tr>
          <?php



          if ($washbay_data != null) {
          ?>
            <tr>
              <td align="left" style="padding:8px; width: 5%;"><?php echo $i++; ?></td>
              <td align="left" style="padding:8px;" colspan="2"><?php echo e(trans('message.Wash Bay Service')); ?></td>
              <td align="left" style="padding:8px;" colspan="2"><?php echo number_format((float) $washbay_data->price, 2); ?></td>
              <td align="right" style="padding:8px; width: 20%;"><?php echo number_format((float) $washbay_data->price, 2); ?></td>
              <?php $total4 += $washbay_data->price; ?>
            </tr>
          <?php
          }
          ?>
          <?php


          if ($mot_status == 1) {
          ?>
            <tr>
              <td align="left" style="padding:8px; width: 5%;"><?php echo $i++; ?></td>
              <td align="left" style="padding:8px;" colspan="2"><?php echo e(trans('message.MOT Testing Charges')); ?></td>
              <td align="left" style="padding:8px;" colspan="2"><?php echo number_format((float)  $tbl_services->mot_charge, 2); ?></td>
              <td align="right" style="padding:8px; width: 20%;"><?php echo number_format((float)  $tbl_services->mot_charge, 2); ?></td>
              <?php $total3 += $tbl_services->mot_charge; ?>
            </tr>
          <?php
          }
          ?>
          <?php foreach ($service_pro2 as $service_pros) { ?>
            <tr>
              <td align="left" style="padding:8px; width: 5%;"><?php echo $i++; ?></td>
              <td align="left" style="padding:8px;" colspan="2"><?php echo $service_pros->comment; ?></td>
              <td align="left" style="padding:8px;" colspan="2"><?php echo number_format((float) $service_pros->total_price, 2); ?></td>
              <td align="right" style="padding:8px; width: 20%;"><?php echo number_format((float) $service_pros->total_price, 2); ?></td>
              <?php $total2 += $service_pros->total_price; ?>
            </tr>
          <?php } ?>

        </tbody>
      </table>
    <?php } ?>

    <!-- Custom Field Of Customer Module (User table)-->
    <?php if(empty($tbl_custom_fields_customers) == 0): ?>
    <?php $showTableHeading = false; ?>
    <?php $__currentLoopData = $tbl_custom_fields_customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbl_custom_fields_customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $tbl_custom = $tbl_custom_fields_customer->id;
    $userid = $tbl_services->customer_id;
    $datavalue = getCustomData($tbl_custom, $userid);
    ?>

    <?php if($tbl_custom_fields_customer->type == 'radio' && $datavalue != ''): ?>
    <?php $showTableHeading = true; ?>
    <?php elseif($datavalue != null): ?>
    <?php $showTableHeading = true; ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($showTableHeading): ?>
    <br />
    <table class="table table-bordered itemtable" width="100%" border="1" style="border-collapse:collapse;">
      <tr class="printimg" style="color:#333;">
        <th align="left" style="padding:8px; font-size:14px;" colspan="2">
          <?php echo e(trans('message.Customer Other Details')); ?>

        </th>
      </tr>
      <?php $__currentLoopData = $tbl_custom_fields_customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbl_custom_fields_customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $tbl_custom = $tbl_custom_fields_customer->id;
      $userid = $tbl_invoices->customer_id;

      $datavalue = getCustomData($tbl_custom, $userid);
      ?>

      <?php if($tbl_custom_fields_customer->type == 'radio'): ?>
      <?php if($datavalue != ''): ?>
      <?php
      $radio_selected_value = getRadioSelectedValue($tbl_custom_fields_customer->id, $datavalue);
      ?>
      <tr>
        <th align="left" style="padding:8px;">
          <?php echo e($tbl_custom_fields_customer->label); ?> :
        </th>
        <td align="left" style="padding:8px;"><?php echo e($radio_selected_value); ?></td>
      </tr>

      <?php endif; ?>
      <?php else: ?>
      <?php if($datavalue != null): ?>
      <tr>
        <th align="left" style="padding:8px;">
          <?php echo e($tbl_custom_fields_customer->label); ?> :
        </th>
        <td align="left" style="padding:8px;"><?php echo e($datavalue); ?></td>
      </tr>
      <?php endif; ?>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php endif; ?>
    <?php endif; ?>
    <!-- Custom Field Invoice Customer Module (User table)-->

    <!-- Custom Field Of Invoice Module-->

    <?php if(!empty($tbl_custom_fields_invoice)): ?>
    <?php $showTableHeading = false; ?>
    <?php $__currentLoopData = $tbl_custom_fields_invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbl_custom_fields_invoices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $tbl_custom = $tbl_custom_fields_invoices->id;
    $userid = $service_tax->id;

    $datavalue = getCustomDataInvoice($tbl_custom, $userid);
    ?>

    <?php if($tbl_custom_fields_invoices->type == 'radio' && $datavalue != ''): ?>
    <?php $showTableHeading = true; ?>
    <?php elseif($datavalue != null): ?>
    <?php $showTableHeading = true; ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($showTableHeading): ?>
    <br />
    <table class="table table-bordered itemtable" width="100%" border="1" style="border-collapse:collapse;">
      <tr class="printimg" style="color:#333;">
        <th align="left" style="padding:8px; font-size:14px;" colspan="2">
          <?php echo e(trans('message.Other Information Of Invoice')); ?>

        </th>
      </tr>
      <?php $__currentLoopData = $tbl_custom_fields_invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbl_custom_fields_invoices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $tbl_custom = $tbl_custom_fields_invoices->id;
      $userid = $service_tax->id;

      $datavalue = getCustomDataInvoice($tbl_custom, $userid);
      ?>

      <?php if($tbl_custom_fields_invoices->type == 'radio'): ?>
      <?php if($datavalue != ''): ?>
      <?php
      $radio_selected_value = getRadioSelectedValue($tbl_custom_fields_invoices->id, $datavalue);
      ?>

      <tr>
        <th align="left" style="padding:8px; ">
          <?php echo e($tbl_custom_fields_invoices->label); ?> :
        </th>
        <td align="left" style="padding:8px;"><?php echo e($radio_selected_value); ?></td>
      </tr>
      <?php endif; ?>
      <?php else: ?>
      <?php if($datavalue != null): ?>
      <tr>
        <th align="left" style="padding:8px;">
          <?php echo e($tbl_custom_fields_invoices->label); ?> :
        </th>
        <td align="left" style="padding:8px;"><?php echo e($datavalue); ?></td>
      </tr>
      <?php endif; ?>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php endif; ?>
    <?php endif; ?>
    <!-- Custom Field Invoice Module End -->

    <!-- For Custom Field Of Service Module-->
    <?php if(!empty($tbl_custom_fields_service)): ?>
    <?php $showTableHeading = false; ?>
    <?php $__currentLoopData = $tbl_custom_fields_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbl_custom_fields_services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $tbl_custom = $tbl_custom_fields_services->id;
    $userid = $tbl_services->id;

    $datavalue = getCustomDataService($tbl_custom, $userid);
    ?>

    <?php if($tbl_custom_fields_services->type == 'radio' && $datavalue != ''): ?>
    <?php $showTableHeading = true; ?>
    <?php elseif($datavalue != null): ?>
    <?php $showTableHeading = true; ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($showTableHeading): ?>
    <br />
    <table class="table table-bordered itemtable" width="100%" border="1" style="border-collapse:collapse;">
      <tr class="printimg" style="color:#333;">
        <th align="left" style="padding:8px; font-size:14px;" colspan="2">
          <?php echo e(trans('message.Other Information Of Service')); ?>

        </th>
      </tr>
      <?php $__currentLoopData = $tbl_custom_fields_service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbl_custom_fields_services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $tbl_custom = $tbl_custom_fields_services->id;
      $userid = $tbl_services->id;

      $datavalue = getCustomDataService($tbl_custom, $userid);
      ?>

      <?php if($tbl_custom_fields_services->type == 'radio'): ?>
      <?php if($datavalue != ''): ?>
      <?php
      $radio_selected_value = getRadioSelectedValue($tbl_custom_fields_services->id, $datavalue);
      ?>

      <tr>
        <th align="left" style="padding:8px;">
          <?php echo e($tbl_custom_fields_services->label); ?> :
        </th>
        <td align="left" style="padding:8px;"><?php echo e($radio_selected_value); ?></td>
      </tr>
      <?php endif; ?>
      <?php else: ?>
      <?php if($datavalue != null): ?>
      <tr>
        <th align="left" style="padding:8px;">
          <?php echo e($tbl_custom_fields_services->label); ?> :
        </th>
        <td align="left" style="padding:8px;"><?php echo e($datavalue); ?></td>
      </tr>
      <?php endif; ?>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php endif; ?>
    <?php endif; ?>
    <!-- For Custom Field Service Module End -->

    <br />
    <table class="table table-bordered itemtable" width="100%" border="1" style="border-collapse:collapse;">
      <tbody>
        <tr>
          <td align="right" style="padding:8px;"><?php echo e(trans('message.Fixed Service Charge')); ?> (<?php echo getCurrencySymbols(); ?>) :</td>
          <td align="right" style="padding:8px; font-size: 17px;"><b><?php $fix = $tbl_services->charge;
                                                                      if (!empty($fix)) {
                                                                        echo number_format($fix, 2);
                                                                      } else {
                                                                        echo trans('message.Free Service');
                                                                      } ?></b></td>
        </tr>
        <tr>
          <td align="right" style="padding:8px;" width="80%"><?php echo e(trans('message.Total Service Amount')); ?> (<?php echo getCurrencySymbols(); ?>) :</td>
          <td align="right" style="padding:8px; font-size: 17px;"><b><?php $total_amt = $total1 + $total2 + $total3 + $total4 + $fix;
                                                                      echo number_format($total_amt, 2); ?></b></td>
        </tr>
        <tr>
          <td align="right" style="padding:8px;" width="80%"><?php echo e(trans('message.Discount')); ?> (<?php echo $tbl_invoices->discount . '%'; ?>) :</td>
          <td align="right" style="padding:8px; font-size: 17px;"><b><?php $discount = ($total_amt * $tbl_invoices->discount) / 100;
                                                                      echo number_format($discount, 2); ?></b></td>
        </tr>
        <tr>
          <td align="right" style="padding:8px;" width="80%"><?php echo e(trans('message.Total')); ?> (<?php echo getCurrencySymbols(); ?>) :</td>
          <td align="right" style="padding:8px; font-size: 17px;"><b><?php $after_dis_total = $total_amt - $discount;
                                                                      echo number_format($after_dis_total, 2); ?></b></td>
        </tr>
        <?php

        if (!empty($service_taxes)) {
          $total_tax = 0;
          $taxes_amount = 0;
          $taxName = null;
          foreach ($service_taxes as $ser_tax) {
            // $taxes_per = preg_replace("/[^0-9,.]/", "", $tax);
            $taxes_to_count = getTaxPercentFromTaxTable($ser_tax);
            $taxes_amount = ($after_dis_total * $taxes_to_count) / 100;

            $total_tax +=  $taxes_amount;

            // if (substr_count($tax, ' ') > 1) {
            //   $taxNumberArray = explode(" ", $tax);

            //   $taxName = $taxNumberArray[0] . " " . $taxNumberArray[1];
            // } else {
            //   $taxName = $tax;
            // }
        ?>
            <tr>
              <td align="right" style="padding:8px;" width="80%"><b><?php echo getTaxNameAndPercentFromTaxTable($ser_tax); ?> (%) :</b></td>
              <td align="right" style="padding:8px; font-size: 17px;"><b><?php $taxes_amount;
                                                                          echo number_format($taxes_amount, 2); ?></b></td>
            </tr>

        <?php  }
          $final_grand_total = $after_dis_total + $total_tax;
        } else {
          $final_grand_total = $after_dis_total;
        }
        ?>

        <?php
        $paid_amount = $tbl_invoices->paid_amount;
        $Adjustmentamount = $final_grand_total - $paid_amount; ?>

        <tr>
          <td align="right" style="padding:8px;" width="80%">
            <?php echo e(trans('message.Adjustment Amount')); ?>(<?php echo e(trans('message.Paid Amount')); ?>)(<?php echo getCurrencySymbols(); ?>) :
          </td>

          <td align="right" style="padding:8px; font-size: 17px;"><b>
              <?php $paid_amount;
              echo number_format($paid_amount, 2); ?></b>
          </td>
        </tr>

        <tr>
          <td align="right" style="padding:8px;" width="80%"><?php echo e(trans('message.Due Amount')); ?> (<?php echo getCurrencySymbols(); ?>):

          </td>
          <td align="right" style="padding:8px; font-size: 17px;"><b><?php $Adjustmentamount;
                                                                      echo number_format($Adjustmentamount, 2); ?></b></td>

        </tr>

        <tr class="grand_total_modal_invoice">
          <td align="right" style="padding:8px;" width="80%"><?php echo e(trans('message.Grand Total')); ?> (<?php echo getCurrencySymbols(); ?>) :</td>
          <td align="right" style="padding:8px; font-size: 17px;"><b><?php $final_grand_total;
                                                                      echo number_format($final_grand_total, 2); ?></b></td>
        </tr>
      </tbody>
    </table>
  </div>


</body>

</html><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/invoice/serviceinvoicepdf.blade.php ENDPATH**/ ?>