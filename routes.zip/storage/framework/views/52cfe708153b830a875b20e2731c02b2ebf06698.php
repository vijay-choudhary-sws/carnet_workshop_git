<div class="modal-header">

    <h4 id="myLargeModalLabel" class="modal-title text-center"><?php echo e(getNameSystem()); ?></h4>


    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
    <!-- <div class="col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-sm-12 col-xs-12">
        <h1 class="text-center"><?php echo e(trans('message.Payment History')); ?></h1>
    </div> -->
    <h4 id="myLargeModalLabel" class="modal-title text-center"><?php echo e(trans('message.Payment History for Invoice Number')); ?> -
        <?php echo e($tbl_invoices->invoice_number); ?>

    </h4>
    <br>


    <div class="table-responsive">
        <?php $total = 0;
        $i = 1; ?>
        <?php if(!empty($tbl_payment_records)): ?>
        <table id="datatable" class="table table-bordered">
            <thead>
                <tr>
                    <th style="width: 5%;">#</th>
                    <th><?php echo e(trans('message.Payment Number')); ?></th>
                    <th><?php echo e(trans('message.Payment Type')); ?></th>
                    <th><?php echo e(trans('message.Payment Date')); ?></th>
                    <th style="width: 20%;"><?php echo e(trans('message.Amount')); ?> (<?php echo e(getCurrencySymbols()); ?>)</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tbl_payment_records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbl_payment_recordss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- <?php if($tbl_payment_recordss->amount != 0): ?> -->

                <tr class="texr-left">
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($tbl_payment_recordss->payment_number); ?></td>
                    <td><?php echo e(GetPaymentMethod($tbl_payment_recordss->payment_type)); ?></td>
                    <td><?php echo e(date(getDateFormat(), strtotime($tbl_payment_recordss->payment_date))); ?></td>
                    <td><?php echo e(number_format($tbl_payment_recordss->amount, 2)); ?> <?php $total += $tbl_payment_recordss->amount; ?></td>

                    <?php $i++; ?>
                </tr>
                <!-- <?php else: ?> -->
                <!-- <tr>
                    <td class="cname text-center" colspan="5"><?php echo e(trans('message.No records are available for unpaid invoice.')); ?></td>
                </tr> -->

            </tbody>
            <!-- <?php endif; ?> -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        <?php endif; ?>
    </div>

    <br />
    <div class="">
        <table class="table paymentmodal table-bordered">
            <tr>
                <td align="right" style="width: 80%;"><?php echo e(trans('message.Total Paid')); ?> (<?php echo e(getCurrencySymbols()); ?>) :</td>
                <td class="fw-bold"> <?php echo e(number_format($total, 2)); ?></td>
            </tr>
            <tr>
                <td align="right"><?php echo e(trans('message.Due Amount')); ?> (<?php echo e(getCurrencySymbols()); ?>) :</td>
                <?php
                $grand_total = $tbl_invoices->grand_total;
                $paid_amount = $tbl_invoices->paid_amount;
                $AmountDue = $grand_total - $paid_amount;
                ?>
                <td class="fw-bold"><?php echo e(number_format($AmountDue, 2)); ?> </td>
            </tr>
        </table>
    </div>
    <div class="modal-footer p-0">
        <button type="button" class="btn btn-outline-secondary btn-sm mx-0" data-bs-dismiss="modal"><?php echo e(trans('message.Close')); ?></button>
    </div>
</div><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/invoice/paymentview.blade.php ENDPATH**/ ?>