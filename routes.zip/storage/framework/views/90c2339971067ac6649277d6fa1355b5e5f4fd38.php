<tr data-row="<?php echo e($row); ?>">
    <td>
        <span><?php echo $mergedData['label_name'].'<small>(Current stock : <b>'.$mergedData['stock'].'</b>)</small>'; ?></span>
        <input type="hidden" class="form-control" name="jobcard_item_id[]" value="<?php echo e($mergedData['label_id']); ?>">
    </td>
    <td><input type="number" class="form-control" name="jobcard_quantity[]" value="1" min="1" max="" step="1" oninput="getJobCardPrice(this)"></td>
    <td><input type="number" class="form-control" name="jobcard_price[]" value="<?php echo e($mergedData['price']); ?>" min="1" step="1" oninput="getJobCardPrice(this)"></td>
    <td><input type="text" class="form-control bg-light" name="jobcard_total_amount[]" readonly value="<?php echo e($mergedData['price']); ?>" min="1"  step="1"></td>
    <td><input type="number" class="form-control" name="jobcard_discount[]" value="0" min="0"  step="1" oninput="getJobCardPrice(this)"></td>
    <td><input type="text" class="form-control bg-light" name="jobcard_final_amount[]" value="<?php echo e($mergedData['price']); ?>" min="1"  step="1" readonly></td>
    <td>
        <select name="employee[]" class="select2">
            <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->display_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </td>
    <td><button class="btn btn-sm btn-danger rounded border-0 text-white" onclick="removeJobCardRow(this)">Remove</button></td>
</tr><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/jobcard/component/add_row.blade.php ENDPATH**/ ?>