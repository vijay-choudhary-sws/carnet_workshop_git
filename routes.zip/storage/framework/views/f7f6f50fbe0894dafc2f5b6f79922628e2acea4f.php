
<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle">
          <a id="menu_toggle"><i class="fa fa-bars sidemenu_toggle"></i></a><span class="titleup">
                <?php echo e(trans('message.General Settings')); ?></span></a>
          </div>
          <?php echo $__env->make('dashboard.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
      </div>
    </div>
    <?php echo $__env->make('success_message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="x_content table-responsive">
      <ul class="nav nav-tabs">
        <li class="nav-item">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('generalsetting_view')): ?>
          <a href="<?php echo url('setting/general_setting/list'); ?>" class="nav-link active"><span class="visible-xs"></span> <i class=""></i><b><?php echo e(trans('message.GENERAL SETTINGS')); ?></b></a>
          <?php endif; ?>
        </li>

        <li class="nav-item">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('timezone_view')): ?>
          <a href="<?php echo url('setting/timezone/list'); ?>" class="nav-link nav-link-not-active"><span class="visible-xs"></span><i class="">&nbsp;</i><b><?php echo e(trans('message.OTHER SETTINGS')); ?></b></a>
          <?php endif; ?>
        </li>

        <li class="nav-item">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accessrights_view')): ?>
          <a href="<?php echo url('setting/accessrights/show'); ?>" class="nav-link nav-link-not-active"><span class="visible-xs"></span><i class="">&nbsp;</i><b><?php echo e(trans('message.ACCESS RIGHTS')); ?></b></a>
          <?php endif; ?>
        </li>

        <li class="nav-item">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('businesshours_view')): ?>
          <a href="<?php echo url('setting/hours/list'); ?>" class="nav-link nav-link-not-active"><span class="visible-xs"></span><i class="">&nbsp;</i><b><?php echo e(trans('message.BUSINESS HOURS')); ?></b></a>
          <?php endif; ?>
        </li>

        <li class="nav-item">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stripesetting_view')): ?>
          <a href="<?php echo url('setting/stripe/list'); ?>" class="nav-link nav-link-not-active"><span class="visible-xs"></span><i class="">&nbsp;</i><b><?php echo e(trans('message.STRIPE SETTINGS')); ?></b></a>
          <?php endif; ?>
        </li>

        <li class="nav-item">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branchsetting_view')): ?>
          <a href="<?php echo url('branch_setting/list'); ?>" class="nav-link nav-link-not-active"><span class="visible-xs"></span><i class="">&nbsp;</i><b><?php echo e(trans('message.BRANCH SETTING')); ?></b></a>
          <?php endif; ?>
        </li>
        
        <li class="nav-item">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('email_view')): ?>
          <a href="<?php echo url('setting/email_setting/list'); ?>" class="nav-link nav-link-not-active"><span class="visible-xs"></span><i class="">&nbsp;</i><b><?php echo e(trans('message.EMAIL SETTING')); ?></b></a>
          <?php endif; ?>
        </li>

      </ul>

    </div>
    <div class="row">
      <div class="col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_content">
            <form id="general_setting_edit_form" method="post" action="<?php echo e(url('setting/general_setting/store')); ?>" enctype="multipart/form-data" class="form-horizontal upperform">

              <div class="col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-sm-12 col-xs-12">
                <h4><b><?php echo e(trans('message.BUSINESS INFORMATION')); ?> </b></h4>
                <p class="col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-sm-12 col-xs-12 ln_solid"></p>
              </div>

              <div class="row mt-3 row-mb-0 has-feedback">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="System_Name"><?php echo e(trans('message.System Name')); ?> <label class="color-danger">*</label>
                </label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                  <input type="text" name="System_Name" class="form-control" placeholder="<?php echo e(trans('message.Enter System Name/Title')); ?>" required maxlength="50" value="<?php echo e($settings_data->system_name); ?>">
                  <?php if($errors->has('System_Name')): ?>
                  <span class="help-block">
                    <span class="text-danger"><?php echo e($errors->first('System_Name')); ?></span>
                  </span>
                  <?php endif; ?>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
              </div>

              <div class="row row-mb-0">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="start_year"><?php echo e(trans('message.Starting Year')); ?> </label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4 date">
                  <input type="text" name="start_year" class="form-control datepicker1" id="" value="<?php echo e($settings_data->starting_year); ?>">
                </div>
              </div>

              <div class="row row-mb-0 has-feedback">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="Phone_Number"><?php echo e(trans('message.Phone Number')); ?> <label class="color-danger">*</label>
                </label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                  <input type="text" name="Phone_Number" class="form-control" placeholder="<?php echo e(trans('message.Enter Phone Number')); ?>" required maxlength="16" minlength="6" value="<?php echo e($settings_data->phone_number); ?>">
                  <?php if($errors->has('Phone_Number')): ?>
                  <span class="help-block">
                    <span class="text-danger"><?php echo e($errors->first('Phone_Number')); ?></span>
                  </span>
                  <?php endif; ?>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
              </div>

              <div class="row row-mb-0 has-feedback">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="Email"><?php echo e(trans('message.Email')); ?> <label class="color-danger">*</label>
                </label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                  <input type="text" name="Email" class="form-control" placeholder="<?php echo e(trans('message.Enter Email Address')); ?>" required value="<?php echo e($settings_data->email); ?>" maxlength="50">
                  <?php if($errors->has('Email')): ?>
                  <span class="help-block">
                    <span class="text-danger"><?php echo e($errors->first('Email')); ?></span>
                  </span>
                  <?php endif; ?>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
              </div>

              <div class="row row-mb-0 has-feedback">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="address"><?php echo e(trans('message.Address')); ?> <label class="color-danger">*</label>
                </label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                  <textarea name="address" class="form-control addressTextarea" rows="4" placeholder="<?php echo e(trans('message.Enter Address')); ?>" maxlength="100" required><?php echo e($settings_data->address); ?></textarea>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
              </div>

              <div class="row row-mb-0 has-feedback">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="Country"><?php echo e(trans('message.Country')); ?> <label class="color-danger">*</label>
                </label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                  <select class="form-control select_country form-select" name="country_id" countryurl="<?php echo url('/getstatefromcountry'); ?>" required>
                    <option value=""><?php echo e(trans('message.Select Country')); ?></option>
                    <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countrys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($countrys->id); ?>" <?php if ($settings_data->country_id == $countrys->id) {
                                                          echo 'selected';
                                                        } ?>><?php echo e($countrys->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
              </div>

              <div class="row row-mb-0 has-feedback">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="state"><?php echo e(trans('message.State')); ?></label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                  <select class="form-control state_of_country form-select" name="state_id" stateurl="<?php echo url('/getcityfromstate'); ?>">
                    <!-- <option value="">Select State</option> -->
                    <?php if(count($state) > 0): ?>
                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $states): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo $states->id; ?>" <?php if ($settings_data->state_id == $states->id) {
                                                          echo 'selected';
                                                        } ?>><?php echo $states->name; ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </select>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
              </div>

              <div class="row row-mb-0 has-feedback">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="city"><?php echo e(trans('message.City')); ?> </label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                  <select class="form-control city_of_state form-select" name="city">
                    <!-- <option value="">Select City</option> -->
                    <?php if(count($city) > 0): ?>
                    <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo $citys->id; ?>" <?php if ($settings_data->city_id == $citys->id) {
                                                          echo 'selected';
                                                        } ?>><?php echo $citys->name; ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </select>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
              </div>
              <?php
              if (isAdmin(Auth::User()->role_id)) {
              ?>
                <div class="row row-mb-0">
                  <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="image"><?php echo e(trans('message.Logo Image')); ?></label>
                  <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                    <input type="file" id="input-file-max-fs" name="Logo_Image" class="form-control dropify" data-max-file-size="5M">
                    <?php if($errors->has('Logo_Image')): ?>
                    <span class="help-block">
                      <span class="text-danger"><?php echo e($errors->first('Logo_Image')); ?></span>
                    </span>
                    <?php endif; ?>
                    <div class="col-md-12 col-sm-12 col-xs-12 printimg">
                      <img src="<?php echo e(url('public/general_setting/' . $settings_data->logo_image)); ?>" class="logo_img" width="100%">
                    </div>
                    <div class="dropify-preview">
                      <span class="dropify-render"></span>
                      <div class="dropify-infos">
                        <div class="dropify-infos-inner">
                          <p class="dropify-filename">
                            <span class="file-icon"></span>
                            <span class="dropify-filename-inner"></span>
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
                </div>
              <?php
              }
              ?>


              <div class="row row-mb-0">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="image"><?php echo e(trans('message.Cover Image')); ?></label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                  <input type="file" id="input-file-max-fs" name="Cover_Image" class="form-control dropify" data-max-file-size="5M">
                  <?php if($errors->has('Cover_Image')): ?>
                  <span class="help-block">
                    <span class="text-danger"><?php echo e($errors->first('Cover_Image')); ?></span>
                  </span>
                  <?php endif; ?>

                  <img src="<?php echo e(url('public/general_setting/' . $settings_data->cover_image)); ?>" class="cov_img mt-2" height="250px" width="100%">

                  <div class="dropify-preview ">
                    <span class="dropify-render"></span>
                    <div class="dropify-infos">
                      <div class="dropify-infos-inner">
                        <p class="dropify-filename">
                          <span class="file-icon"></span>
                          <span class="dropify-filename-inner"></span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
              </div>

              <div class="row row-mb-0 has-feedback">
                <label class="control-label col-md-2 col-lg-2 col-xl-2 col-xxl-2 col-sm-2 col-xs-2 checkpointtext text-end" for="Paypal_Id"><?php echo e(trans('message.Paypal Email Id')); ?>

                </label>
                <div class="col-md-4 col-lg-4 col-xl-4 col-xxl-4 col-sm-4 col-xs-4">
                  <input type="text" name="Paypal_Id" class="form-control" placeholder="<?php echo e(trans('message.Enter Paypal Email Address')); ?>" maxlength="50" value="<?php echo e($settings_data->paypal_id); ?>">
                  <?php if($errors->has('Paypal_Id')): ?>
                  <span class="help-block">
                    <span class="text-danger"><?php echo e($errors->first('Paypal_Id')); ?></span>
                  </span>
                  <?php endif; ?>
                </div>
                <div class="col-md-3 col-lg-3 col-xl-3 col-xxl-3 col-sm-3 col-xs-3"></div>
              </div>
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('generalsetting_edit')): ?>

              <div class="row row-mb-0 has-feedback">
                <!-- <div class="col-md-6 col-lg-6 col-xl-6 col-xxl-6 col-sm-6 col-xs-6 form-group ">
                  <a class="btn cancel" href="<?php echo e(URL::previous()); ?>"><?php echo e(trans('message.CANCEL')); ?></a>
                </div> -->
                <div class="row col-md-6 col-lg-6 col-xl-6 col-xxl-6 col-sm-6 col-xs-6 form-group my-2 mx-0">
                  <input type="submit" class="btn update general_setting_update" value="<?php echo e(trans('message.UPDATE')); ?>" />
                </div>

              </div>
              <?php endif; ?>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- page content end -->

<script src="<?php echo e(URL::asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>

<script>
  $(document).ready(function() {

    $('.select_country').change(function() {

      countryid = $(this).val();
      var url = $(this).attr('countryurl');

      $.ajax({
        type: 'GET',
        url: url,
        data: {
          countryid: countryid
        },
        success: function(response) {
          $('.state_of_country').html(response);
        }
      });
    });

    $('body').on('change', '.state_of_country', function() {
      stateid = $(this).val();

      var url = $(this).attr('stateurl');
      $.ajax({
        type: 'GET',
        url: url,
        data: {
          stateid: stateid
        },
        success: function(response) {
          $('.city_of_state').html(response);
        }
      });
    });


    /*datetimepicker in starting_year*/
    $('.datepicker1').datetimepicker({
      format: "yyyy",
      endDate: new Date(),
      minView: 4,
      autoclose: true,
      startView: 4,
      language: "<?php echo e(getLangCode()); ?>",
    });


    // Basic
    $('.dropify').dropify();

    // Translated
    $('.dropify-fr').dropify({
      messages: {
        default: 'Glissez-déposez un fichier ici ou cliquez',
        replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
        remove: 'Supprimer',
        error: 'Désolé, le fichier trop volumineux'
      }
    });

    // Used events
    var drEvent = $('#input-file-events').dropify();

    drEvent.on('dropify.beforeClear', function(event, element) {
      return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
    });

    drEvent.on('dropify.afterClear', function(event, element) {
      var msg1 = "<?php echo e(trans('message.File deleted')); ?>";

      alert(msg1);
    });

    drEvent.on('dropify.errors', function(event, element) {
      console.log('Has Errors');
    });

    var drDestroy = $('#input-file-to-destroy').dropify();
    drDestroy = drDestroy.data('dropify')
    $('#toggleDropify').on('click', function(e) {
      e.preventDefault();
      if (drDestroy.isDropified()) {
        drDestroy.destroy();
      } else {
        drDestroy.init();
      }
    })


    /*If address have any white space then make empty address value*/
    $('body').on('keyup', '.addressTextarea', function() {

      var addressValue = $(this).val();

      if (!addressValue.replace(/\s/g, '').length) {
        $(this).val("");
      }
    });
  });
</script>

<!-- Form field validation -->
<?php echo JsValidator::formRequest('App\Http\Requests\StoreGeneralSettingEditFormRequest', '#general_setting_edit_form'); ?>

<script type="text/javascript" src="<?php echo e(asset('public/vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp8.2.12\htdocs\carnate_workshop_new\resources\views/general_setting/list.blade.php ENDPATH**/ ?>