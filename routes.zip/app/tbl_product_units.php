<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_product_units extends Authenticatable
{
    
}
