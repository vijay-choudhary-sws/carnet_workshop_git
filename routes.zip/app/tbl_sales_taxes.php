<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_sales_taxes extends Authenticatable
{
    
}
