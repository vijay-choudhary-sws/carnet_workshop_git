<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_vehicle_colors extends Authenticatable
{
    
}
