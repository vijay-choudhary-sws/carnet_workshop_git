<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_fuel_types extends Authenticatable
{
    
}