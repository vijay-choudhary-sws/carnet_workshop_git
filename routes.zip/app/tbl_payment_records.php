<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_payment_records extends Authenticatable
{
    
}
