<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_service_observation_points extends Authenticatable
{
    
}
