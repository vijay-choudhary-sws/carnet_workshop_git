<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_service_images extends Model
{
    protected $table = 'tbl_service_images';
}
