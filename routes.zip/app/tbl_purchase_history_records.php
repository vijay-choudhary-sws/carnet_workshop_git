<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_purchase_history_records extends Authenticatable
{
  
}