<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RepairCategory extends Model
{
    //
    protected $table = 'table_repair_category';
}
