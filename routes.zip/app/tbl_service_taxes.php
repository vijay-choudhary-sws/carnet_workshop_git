<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_service_taxes extends Authenticatable
{
    
}
