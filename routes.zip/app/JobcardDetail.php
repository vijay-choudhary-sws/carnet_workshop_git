<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobcardDetail  extends Model
{
    //For 
    protected $table = 'tbl_jobcard_details';
}
