<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_add_payments extends Authenticatable
{
    
}