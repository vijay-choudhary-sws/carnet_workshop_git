<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_checkout_results extends Authenticatable
{
    
}
