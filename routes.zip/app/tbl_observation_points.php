<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class tbl_observation_points extends Authenticatable
{
    
}
