<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vehiclebrand extends Model
{
    //
    protected $table = 'tbl_vehicle_brands';
}
