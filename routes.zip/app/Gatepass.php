<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gatepass extends Model
{
    //For 
    protected $table = 'tbl_gatepasses';
}
