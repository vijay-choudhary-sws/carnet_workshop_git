/*For Accordion 1*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus1').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");			
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});

/*For Accordion 2*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus2').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");			
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});


/*For Accordion 3*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus3').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");			
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});

/*For Accordion 4*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus4').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");			
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});

/*For Accordion 5*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus5').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");			
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});

/*For Accordion 6*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus6').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");			
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});

/*For Accordion 7*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus7').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});

/*For Accordion 8*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus8').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");			
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});

/*For Accordion 9*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus9').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");			
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});

/*For Accordion 10*/
$(document).ready(function(){
	var i = 0;
	$('.makePlusMinus10').click(function(){
		i = i+1;
		if(i%2!=0){
			$(this).parent().find(".glyphicon-plus:first").removeClass("glyphicon-plus").addClass("glyphicon-minus");			
		}else{
			$(this).parent().find(".glyphicon-minus:first").removeClass("glyphicon-minus").addClass("glyphicon-plus");
		}
	});
});