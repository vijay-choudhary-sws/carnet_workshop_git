<!DOCTYPE html>
<html lang="en-US">

<head>
  <meta charset="utf-8">
</head>

<body>
  <h2></h2>

  <div>
    <p> {!! $email_content1 !!}.</p>

  </div>

</body>

</html>
