<!DOCTYPE html>
<html lang="en-US">

<head>
  <meta charset="utf-8">
</head>
<!-- Bootstrap -->
<link href="{{ URL::asset('vendors/bootstrap/dist/css/bootstrap.min.css') }}"
  rel="stylesheet">

<body>
  <h2></h2>

  <div>
    <p> {!! $email_content1 !!}.</p>
  </div>
</body>

</html>
