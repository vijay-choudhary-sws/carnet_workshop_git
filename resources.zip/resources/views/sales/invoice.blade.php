<table width="100%"
  border="0">
  <tbody>
    <tr>
      <td width="60%"
        align="left"
        style="float: left;width: 100%;">
        <table width="80%">
          <tr>
            <td colspan="2"
              valign="top">
              <h3></h3>
            </td>
          </tr>

          <tr>
            <td style="background-color:rgba(96, 125, 139, 0.7); padding:0px 12px; margin-right: 10px; float:left;">
            </td>

            <td valign="top">
              <?php
              echo 'sghgdssds';
              ?>
            </td>
          </tr>
        </table>
      </td>
      <td align="left"
        width="25%">
        <b>Bill Number :</b><?php echo '45454545'; ?></br>

      </td>
    </tr>
  </tbody>
</table>
