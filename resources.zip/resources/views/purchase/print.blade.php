<table width="100%"
  border="0">
  <tbody>
    <tr>

      <td align="left"
        width="30%">
        <strong>Purchase Number : </strong><?php echo 'dsdsd'; ?><br>

      </td>
    </tr>
  </tbody>
</table>
<br />
</hr>
