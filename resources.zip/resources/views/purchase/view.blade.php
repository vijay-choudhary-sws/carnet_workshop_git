<div>
  {{ $purchas->id }}
</div>
